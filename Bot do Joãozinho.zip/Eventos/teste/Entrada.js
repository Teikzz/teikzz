const { WebhookClient, EmbedBuilder, ActionRowBuilder, ButtonBuilder, PermissionFlagsBits, ButtonStyle } = require("discord.js");
const { configuracao } = require("../../DataBaseJson");

function getCreationDateFromSnowflake(snowflake) {
    const discordEpoch = 1420070400000; // 1 de Janeiro de 2015
    const binary = parseInt(snowflake).toString(2).padStart(64, '0');
    const timestamp = parseInt(binary.substring(0, 42), 2) + discordEpoch;
    return new Date(timestamp);
}

module.exports = {
    name: 'guildMemberAddentrada',

    run: async (member, client) => {
        try {
            const roleMembroId = configuracao.get("ConfigRoles.cargomembro");
            if (roleMembroId) {
                const role = member.guild.roles.cache.get(roleMembroId);
                if (role) {
                    await member.roles.add(role);
                } else {
                    console.error("Cargo não encontrado no servidor.");
                }
            }

            const channelaasdawdw = configuracao.get("ConfigChannels.boasvindascoole");
            const gggg = configuracao.get("Entradas.msg");

            const mapeamentoSubstituicao = {
                "{member}": `<@${member.user.id}>`,
                "{guildname}": `${member.guild.name}`
            };

            const substituirPalavras = (match) => mapeamentoSubstituicao[match] || match;
            const stringNova = gggg.replace(/{member}|{guildname}/g, substituirPalavras);

            const row222 = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('asSs')
                        .setLabel('Mensagem do Sistema')
                        .setStyle(ButtonStyle.Secondary)
                        .setDisabled(true)
                );

                const channel = client.channels.cache.get(channelaasdawdw);
                
                if (channel) {
                        await channel.send({ components: [row222], content: `${stringNova}` }).then(msg => {
                            if (configuracao.get("Entradas.tempo") > 0) {
                                setTimeout(async () => {
                                    try {
                                        await msg.delete();
                                    } catch (error) {
                                        console.error("Erro ao deletar mensagem:", error);
                                    }
                                }, configuracao.get("Entradas.tempo") * 1000);
                            }
                        });
                }
        } catch (error) {
            console.error("Erro no manipulador de evento guildMemberAdd:", error);
        }

        const fffffffff2222222 = configuracao.get("AntiFake.nomes");

        if (fffffffff2222222 !== null) {
            //console.log("Lista de nomes para checagem anti-fake carregada:", fffffffff2222222);
            const contemNome = fffffffff2222222.some(nome => {
                const isNameIncluded = member.user.username.includes(nome);
                console.log(`Checando nome "${nome}" contra username "${member.user.username}": ${isNameIncluded}`);
                return isNameIncluded;
            });
        
            if (contemNome) {
               // console.log(`Nome "${member.user.username}" está na blacklist, preparando para expulsar.`);
                await member.kick();
                //console.log(`Usuário "${member.user.username}" expulso.`);
        
                const embed = new EmbedBuilder()
                    .setAuthor({ name: `${member.user.username}` })
                    .setTitle("Anti-Fake")
                    .setDescription(`Usuário foi expulso por ter o nome \`${member.user.username}\` que está na blacklist.`)
                    .addFields(
                        { name: "User ID", value: `${member.user.id}`, inline: true },
                        { name: "Data de criação", value: `<t:${Math.ceil(getCreationDateFromSnowflake(member.user.id) / 1000)}:R>`, inline: true }
                    )
                    .setFooter({
                        text: `${member.guild.name}`
                    })
                    .setTimestamp()
                    .setColor(`${configuracao.get("Cores.Principal") == null ? "#fcba03" : configuracao.get("Cores.Principal")}`);
        
                try {
                    const channel = client.channels.cache.get(configuracao.get("ConfigChannels.boasvindascoole"));
                    if (channel) {
                        console.log("Enviando embed para o canal.");
                        await channel.send({ embeds: [embed] });
                        console.log("Embed enviado com sucesso.");
                    } else {
                        console.error("Canal não encontrado para enviar o embed.");
                    }
                } catch (error) {
                    console.error("Erro ao enviar embed:", error);
                }
            }
        }
        
    }
}

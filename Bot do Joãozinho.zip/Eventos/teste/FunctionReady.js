const { carregarCache } = require('../../Handler/EmojiFunctions');
const { CloseThreds } = require('../../Functions/CloseThread');
const { VerificarPagamento } = require('../../Functions/VerficarPagamento');
const { EntregarPagamentos } = require('../../Functions/AprovarPagamento');
const { CheckPosition } = require('../../Functions/PosicoesFunction.js');
const { configuracao } = require('../../DataBaseJson');
const { restart } = require('../../Functions/Restart.js');
const { Varredura } = require('../../Functions/Varredura.js');
const colors = require("colors");
const { ActivityType } = require('discord.js');

module.exports = {
    name: 'ready',

    run: async (client, interaction) => {
        const configuracoes = ['Status1', 'Status2'];
        let indiceAtual = 0;

        // Alterna status do bot em intervalos
        function setActivityWithInterval(client, configuracoes, type, interval) {
            setInterval(() => {
                const configuracaoKey = configuracoes[indiceAtual];
                const status = configuracao[configuracaoKey];

                if (status !== null) {
                    client.user.setActivity(status, { type, url: "https://www.twitch.tv/discord" });
                }

                indiceAtual = (indiceAtual + 1) % configuracoes.length;
            }, interval);
        }

        setActivityWithInterval(client, configuracoes, ActivityType.Streaming, 5000);

        // Sair automaticamente de servidores extras
        if (client.guilds.cache.size > 4) {
            client.guilds.cache.forEach(guild => {
                guild.leave()
                    .then(() => console.log(`Bot saiu do servidor: ${guild.name}`))
                    .catch(error => console.error(`Erro ao sair do servidor: ${guild.name}`, error));
            });
        }

        // Funções de atualização periódica
        setInterval(() => VerificarPagamento(client), 10000);
        setInterval(() => EntregarPagamentos(client, interaction), 14000);
        setInterval(() => CloseThreds(client), 60000);
        setInterval(async () => await UpdateGeral(client), 15 * 60 * 1000);

        // Reinício e varredura
        restart(client);
        Varredura(client);

        async function UpdateGeral(client) {
            let config = {
                method: 'GET',
                headers: {
                    'token': 'ac3add76c5a3c9fd6952a#'
                }
            };

            const description = "**Dz7 lindo*\n<3";

            try {
                const addonsFetch = await fetch(`http://apivendas.squareweb.app/api/v1/adicionais/${client.user.id}`, config);
                
                if (addonsFetch.ok) {
                    const addonsData = await addonsFetch.json();
                    
                    if (addonsData && addonsData.adicionais?.RemoverAnuncio !== true) {
                        const endpoint = `https://discord.com/api/v9/applications/${client.user.id}`;
                        const headers = {
                            "Authorization": `Bot ${client.token}`,
                            "Content-Type": "application/json"
                        };

                        const response = await fetch(endpoint, { headers, method: "PATCH", body: JSON.stringify({}) });
                        
                        if (response.ok) {
                            const body = await response.json();
                            
                            if (body && JSON.stringify(body.description) !== JSON.stringify(description)) {
                                await fetch(endpoint, { headers, method: "PATCH", body: JSON.stringify({ description }) });
                            }
                        } else {
                            console.error("Erro na resposta da API do Discord:", await response.text());
                        }
                    }
                } else {
                    console.error("Erro ao buscar dados adicionais:", addonsFetch.statusText);
                }
            } catch (error) {
                console.error('Erro ao realizar a requisição de UpdateGeral:', error);
            }

            console.clear();
            console.log(`\x1b[36m[INFO]\x1b[32m ${client.user.tag} Foi iniciado - Atualmente em ${client.guilds.cache.size} servidores! - Tendo acesso a ${client.channels.cache.size} canais! - Contendo ${client.guilds.cache.reduce((a, b) => a + b.memberCount, 0)} usuários!\x1b[0m`);

            CheckPosition(client);
            carregarCache();
        }
    }
};

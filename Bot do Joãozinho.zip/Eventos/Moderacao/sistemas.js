const { EmbedBuilder, ActionRowBuilder, ButtonBuilder } = require("discord.js");
const { JsonDatabase } = require("wio.db");
const GeneralJson = new JsonDatabase({ databasePath: "./DataBaseJson/moderacao.json" }) 

module.exports = {
    name:"interactionCreate",
    run: async( interaction, client) => {
        if(interaction.isButton() && interaction.customId === "configsistemas") {

            const embedsistemas = new EmbedBuilder()
            .setAuthor({ name: `${interaction.user.username} - Sistemas`, iconURL: interaction.user.displayAvatarURL() })
            .setDescription(`Olá ${interaction.user},\n\nNesta seção, você pode ajustar as configurações do sistema de sugestões e feedbacks. Faça as alterações necessárias para evitar conflitos no funcionamento do bot. Se preferir não realizar nenhuma configuração, basta não fazer nada.`)
            .setColor("#007BFF")

            const sistemas1 = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                .setLabel("Sugestões (ON/OFF)")
                .setEmoji(GeneralJson.get("sugestao.ativo") === false ? `1295604602456244228` : `1295604569933348864`)
                .setCustomId("onoff_sugestao")
                .setStyle(GeneralJson.get("sugestao.ativo") === false ? 4 : 3),
                new ButtonBuilder()
                .setLabel("Configurar Sistema de Sugestão")
                .setEmoji("1283864133258838058")
                .setCustomId("configsugestao")
                .setStyle(2)
            )

            const sistemas2 = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                .setLabel("Feedbacks (ON/OFF)")
                .setEmoji(GeneralJson.get("feedbacks.ativo") === false ? `1295604602456244228` : `1295604569933348864`)
                .setCustomId("onoff_feedbacks")
                .setStyle(GeneralJson.get("feedbacks.ativo") === false ? 4 : 3),
                new ButtonBuilder()
                .setLabel("Configurar Sistema de Feedbacks")
                .setEmoji("1283864133258838058")
                .setCustomId("configfeedbacks")
                .setStyle(2)
            )
            const sistemas3 = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                .setLabel("Voltar")
                .setEmoji("1269966035575115811")
                .setCustomId("moderacaoslatestebot")
                .setStyle(1),
                new ButtonBuilder()
                .setLabel("Configurar Paineis")
                .setEmoji("1294463426093121536")
                .setCustomId("configpainel")
                .setStyle(1)
            )
            await interaction.update({ embeds: [embedsistemas], components: [sistemas1, sistemas2,sistemas3], ephemeral: true })

        }

        if(interaction.isButton() && interaction.customId === "onoff_sugestao") {

            const statusSugestao = GeneralJson.get("sugestao.ativo")
            const novoStatusSugestao = !statusSugestao
            GeneralJson.set("sugestao.ativo", novoStatusSugestao);

            const embedsistemas = new EmbedBuilder()
            .setAuthor({ name: `${interaction.user.username} - Sistemas`, iconURL: interaction.user.displayAvatarURL() })
            .setDescription(`Olá ${interaction.user},\n\nNesta seção, você pode ajustar as configurações do sistema de sugestões e feedbacks. Faça as alterações necessárias para evitar conflitos no funcionamento do bot. Se preferir não realizar nenhuma configuração, basta não fazer nada.`)
            .setColor("#007BFF")

            const sistemas1 = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                .setLabel("Sugestões (ON/OFF)")
                .setEmoji(GeneralJson.get("sugestao.ativo") === false ? `1295604602456244228` : `1295604569933348864`)
                .setCustomId("onoff_sugestao")
                .setStyle(GeneralJson.get("sugestao.ativo") === false ? 4 : 3),
                new ButtonBuilder()
                .setLabel("Configurar Sistema de Sugestão")
                .setEmoji("1283864133258838058")
                .setCustomId("configsugestao")
                .setStyle(2)
            )

            const sistemas2 = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                .setLabel("Feedbacks (ON/OFF)")
                .setEmoji(GeneralJson.get("feedbacks.ativo") === false ? `1295604602456244228` : `1295604569933348864`)
                .setCustomId("onoff_feedbacks")
                .setStyle(GeneralJson.get("feedbacks.ativo") === false ? 4 : 3),
                new ButtonBuilder()
                .setLabel("Configurar Sistema de Feedbacks")
                .setEmoji("1283864133258838058")
                .setCustomId("configfeedbacks")
                .setStyle(2)
            )
            const sistemas3 = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                .setLabel("Voltar")
                .setEmoji("1269966035575115811")
                .setCustomId("moderacaoslatestebot")
                .setStyle(1),
                new ButtonBuilder()
                .setLabel("Configurar Paineis")
                .setEmoji("1294463426093121536")
                .setCustomId("configpainel")
                .setStyle(1)
            )
            await interaction.update({ embeds: [embedsistemas], components: [sistemas1, sistemas2,sistemas3], ephemeral: true })

        }

        if(interaction.isButton() && interaction.customId === "onoff_feedbacks") {

            const statusFeedbacks = GeneralJson.get("feedbacks.ativo")
            const novoStatusFeedbacks = !statusFeedbacks
            GeneralJson.set("feedbacks.ativo", novoStatusFeedbacks);

            const embedsistemas = new EmbedBuilder()
            .setAuthor({ name: `${interaction.user.username} - Sistemas`, iconURL: interaction.user.displayAvatarURL() })
            .setDescription(`Olá ${interaction.user},\n\nNesta seção, você pode ajustar as configurações do sistema de sugestões e feedbacks. Faça as alterações necessárias para evitar conflitos no funcionamento do bot. Se preferir não realizar nenhuma configuração, basta não fazer nada.`)
            .setColor("#007BFF")

            const sistemas1 = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                .setLabel("Sugestões (ON/OFF)")
                .setEmoji(GeneralJson.get("sugestao.ativo") === false ? `1295604602456244228` : `1295604569933348864`)
                .setCustomId("onoff_sugestao")
                .setStyle(GeneralJson.get("sugestao.ativo") === false ? 4 : 3),
                new ButtonBuilder()
                .setLabel("Configurar Sistema de Sugestão")
                .setEmoji("1283864133258838058")
                .setCustomId("configsugestao")
                .setStyle(2)
            )

            const sistemas2 = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                .setLabel("Feedbacks (ON/OFF)")
                .setEmoji(GeneralJson.get("feedbacks.ativo") === false ? `1295604602456244228` : `1295604569933348864`)
                .setCustomId("onoff_feedbacks")
                .setStyle(GeneralJson.get("feedbacks.ativo") === false ? 4 : 3),
                new ButtonBuilder()
                .setLabel("Configurar Sistema de Feedbacks")
                .setEmoji("1283864133258838058")
                .setCustomId("configfeedbacks")
                .setStyle(2)
            )
            const sistemas3 = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                .setLabel("Voltar")
                .setEmoji("1269966035575115811")
                .setCustomId("moderacaoslatestebot")
                .setStyle(1),
                new ButtonBuilder()
                .setLabel("Configurar Paineis")
                .setEmoji("1294463426093121536")
                .setCustomId("configpainel")
                .setStyle(1)
            )
            await interaction.update({ embeds: [embedsistemas], components: [sistemas1, sistemas2,sistemas3], ephemeral: true })

        }

        if(interaction.isButton() && interaction.customId === "moderacaobotaopainel") {

            const painel = new EmbedBuilder()
        .setAuthor({ name: `${interaction.user.username} - Painel de configuração`, iconURL: interaction.user.displayAvatarURL() })
        .setDescription(`Olá ${interaction.user},\n\nEste é o seu painel de configuração, um espaço especialmente projetado para você otimizar todos os sistemas do bot. Aqui, você terá total controle sobre sugestões e feedbacks, permitindo que ajuste cada detalhe para garantir uma experiência fluida e sem problemas. Aproveite essa oportunidade para personalizar suas configurações e fazer com que tudo funcione perfeitamente para você!`)
        .setColor("#95a5a6")

        const botaopainel = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
            .setLabel("Configurar Sistemas")
            .setEmoji("1292990181208490088")
            .setCustomId("configsistemas")
            .setStyle(1),
            new ButtonBuilder()
            .setLabel("Personalizar Painel")
            .setEmoji("1294463426093121536")
            .setCustomId("configpainel")
            .setStyle(2),
            new ButtonBuilder()
            .setLabel("Voltar")
            .setEmoji("1284062277430939669")
            .setCustomId("voltar00")
            .setStyle(2)
        )

        await interaction.update({ embeds: [painel], components: [botaopainel], ephemeral: true })

        }

        if(interaction.isButton() && interaction.customId === "back2") {

            const embedsistemas = new EmbedBuilder()
            .setAuthor({ name: `${interaction.user.username} - Sistemas`, iconURL: interaction.user.displayAvatarURL() })
            .setDescription(`Olá ${interaction.user},\n\nNesta seção, você pode ajustar as configurações do sistema de sugestões e feedbacks. Faça as alterações necessárias para evitar conflitos no funcionamento do bot. Se preferir não realizar nenhuma configuração, basta não fazer nada.`)
            .setColor("#007BFF")

            const sistemas1 = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                .setLabel("Sugestões (ON/OFF)")
                .setEmoji(GeneralJson.get("sugestao.ativo") === false ? `1295604602456244228` : `1295604569933348864`)
                .setCustomId("onoff_sugestao")
                .setStyle(GeneralJson.get("sugestao.ativo") === false ? 4 : 3),
                new ButtonBuilder()
                .setLabel("Configurar Sistema de Sugestão")
                .setEmoji("1283864133258838058")
                .setCustomId("configsugestao")
                .setStyle(2)
            )

            const sistemas2 = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                .setLabel("Feedbacks (ON/OFF)")
                .setEmoji(GeneralJson.get("feedbacks.ativo") === false ? `1295604602456244228` : `1295604569933348864`)
                .setCustomId("onoff_feedbacks")
                .setStyle(GeneralJson.get("feedbacks.ativo") === false ? 4 : 3),
                new ButtonBuilder()
                .setLabel("Configurar Sistema de Feedbacks")
                .setEmoji("1283864133258838058")
                .setCustomId("configfeedbacks")
                .setStyle(2)
            )
            const sistemas3 = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                .setLabel("Voltar")
                .setEmoji("1269966035575115811")
                .setCustomId("moderacaoslatestebot")
                .setStyle(1),
                new ButtonBuilder()
                .setLabel("Configurar Paineis")
                .setEmoji("1294463426093121536")
                .setCustomId("configpainel")
                .setStyle(1)
            )
            await interaction.update({ embeds: [embedsistemas], components: [sistemas1, sistemas2,sistemas3], ephemeral: true })

        }

        if(interaction.isButton() && interaction.customId === "configsugestao") {

            const embedconfigsugestao = new EmbedBuilder()
            .setAuthor({ name: `${interaction.user.username} - Configuração de Sistema de Sugestão`, iconURL: interaction.user.displayAvatarURL() })
            .setDescription(`Olá ${interaction.user},\n\nNesta seção, você pode configurar o seu sistema de sugestões. Defina onde as sugestões serão registradas, especifique o cargo necessário para enviar sugestões e ajuste outras opções conforme necessário.`)
            .setColor("#00BFFF")

            const botaoconfigsugestao = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                .setLabel("Definir Cargo de Sugestões")
                .setEmoji("1293361144190341163")
                .setCustomId("cargosugestao")
                .setStyle(2),
                new ButtonBuilder()
                .setLabel("Definir Logs de Sugestão")
                .setEmoji("1293361144190341163")
                .setCustomId("sugestaologs")
                .setStyle(2),
                new ButtonBuilder()
                .setLabel("Voltar")
                .setEmoji("1269966035575115811")
                .setCustomId("back2")
                .setStyle(1)
            )

            await interaction.update({ embeds: [embedconfigsugestao], components: [botaoconfigsugestao], ephemeral: true })

        }

        if (interaction.isButton() && interaction.customId === "cargosugestao") {
            await interaction.reply({
                content: `🤔・Marque o cargo necessário para enviar sugestões, caso não deseje definir um cargo, basta digitar "remover".`,
                ephemeral: true
            });
        
            const filter = response => response.author.id === interaction.user.id;
        
            const collector = interaction.channel.createMessageCollector({ filter, max: 1, time: 60000 });
        
            collector.on('collect', async message => {
                const cargoMencionado = message.mentions.roles.first();
                message.delete()
        
                if (cargoMencionado) {
                    const cargoID = cargoMencionado.id;
        
                   await GeneralJson.set("sugestao.cargo", cargoID);
        
                    await interaction.editReply({ content: `✅・O cargo ${cargoMencionado} foi definido como cargo necessário para enviar sugestões com sucesso!`, ephemeral: true });
                } else if (message.content.toLowerCase() === "remover") {
                    await GeneralJson.set("sugestao.cargo", "null");
                    await interaction.editReply({ content: `✅・O cargo necessário para enviar sugestões foi removido com sucesso!`, ephemeral: true });
                } else {
                    await interaction.editReply({ content: `❌・Marque um cargo valido, ou digite "remover"!`, ephemeral: true });
                }
        
                collector.stop();
            });
        
            collector.on('end', collected => {
                if (collected.size === 0) {
                    interaction.editReply({ content: `❌・O tempo para a resposta esgotou!`, ephemeral: true });
                }
            });
        }

        if (interaction.isButton() && interaction.customId === "sugestaologs") {
            await interaction.reply({
                content: `🤔・Marque o canal onde ira mostrar as sugestões enviadas, caso não deseje definir um canal, basta digitar "remover".`,
                ephemeral: true
            });
        
            const filter = response => response.author.id === interaction.user.id;
        
            const collector = interaction.channel.createMessageCollector({ filter, max: 1, time: 60000 });
        
            collector.on('collect', async message => {
                const canalMencionado = message.mentions.channels.first();
                message.delete()
        
                if (canalMencionado) {
                    const canalID = canalMencionado.id;
        
                   await GeneralJson.set("sugestao.logs", canalID);
        
                    await interaction.editReply({ content: `✅・O canal ${canalMencionado} foi definido como logs de sugestões com sucesso!`, ephemeral: true });
                } else if (message.content.toLowerCase() === "remover") {
                    await GeneralJson.set("sugestao.logs", "null");
                    await interaction.editReply({ content: `✅・O canal de logs sugestões foi removido com sucesso!`, ephemeral: true });
                } else {
                    await interaction.editReply({ content: `❌・Marque um canal valido, ou digite "remover"!`, ephemeral: true });
                }
        
                collector.stop();
            });
        
            collector.on('end', collected => {
                if (collected.size === 0) {
                    interaction.editReply({ content: `❌・O tempo para a resposta esgotou!`, ephemeral: true });
                }
            });
        }

        if(interaction.isButton() && interaction.customId === "configfeedbacks") {

            const embedconfigfeedbacks = new EmbedBuilder()
            .setAuthor({ name: `${interaction.user.username} - Configuração de Sistema de Feedbacks`, iconURL: interaction.user.displayAvatarURL() })
            .setDescription(`Olá ${interaction.user},\n\nNesta seção, você pode configurar o seu sistema de feedbacks. Defina onde as sugestões serão registradas, especifique o cargo necessário para enviar feedbacks e ajuste outras opções conforme necessário.`)
            .setColor("#00BFFF")

            const botaoconfigfeedbacks = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                .setLabel("Definir Cargo de Feedbacks")
                .setEmoji("1293361144190341163")
                .setCustomId("cargofeedbacks")
                .setStyle(2),
                new ButtonBuilder()
                .setLabel("Definir Logs de Feedbacks")
                .setEmoji("1293361144190341163")
                .setCustomId("feedbacklogs")
                .setStyle(2),
                new ButtonBuilder()
                .setLabel("Voltar")
                .setEmoji("1269966035575115811")
                .setCustomId("back2")
                .setStyle(1)
            )

            await interaction.update({ embeds: [embedconfigfeedbacks], components: [botaoconfigfeedbacks], ephemeral: true })

        }

        if (interaction.isButton() && interaction.customId === "cargofeedbacks") {
            await interaction.reply({
                content: `🤔・Marque o cargo necessário para enviar feedbacks, caso não deseje definir um cargo, basta digitar "remover".`,
                ephemeral: true
            });
        
            const filter = response => response.author.id === interaction.user.id;
        
            const collector = interaction.channel.createMessageCollector({ filter, max: 1, time: 60000 });
        
            collector.on('collect', async message => {
                const cargoMencionado = message.mentions.roles.first();
                message.delete()
        
                if (cargoMencionado) {
                    const cargoID = cargoMencionado.id;
        
                   await GeneralJson.set("feedbacks.cargo", cargoID);
        
                    await interaction.editReply({ content: `✅・O cargo ${cargoMencionado} foi definido como cargo necessário para enviar feedbacks com sucesso!`, ephemeral: true });
                } else if (message.content.toLowerCase() === "remover") {
                    await GeneralJson.set("feedbacks.cargo", "null");
                    await interaction.editReply({ content: `✅・O cargo necessário para enviar feedbacks foi removido com sucesso!`, ephemeral: true });
                } else {
                    await interaction.editReply({ content: `❌・Marque um cargo valido, ou digite "remover"!`, ephemeral: true });
                }
        
                collector.stop();
            });
        
            collector.on('end', collected => {
                if (collected.size === 0) {
                    interaction.editReply({ content: `❌・O tempo para a resposta esgotou!`, ephemeral: true });
                }
            });
        }

        if (interaction.isButton() && interaction.customId === "feedbacklogs") {
            await interaction.reply({
                content: `🤔・Marque o canal onde ira mostrar os feedbacks enviados, caso não deseje definir um canal, basta digitar "remover".`,
                ephemeral: true
            });
        
            const filter = response => response.author.id === interaction.user.id;
        
            const collector = interaction.channel.createMessageCollector({ filter, max: 1, time: 60000 });
        
            collector.on('collect', async message => {
                const canalMencionado = message.mentions.channels.first();
                message.delete()
        
                if (canalMencionado) {
                    const canalID = canalMencionado.id;
        
                   await GeneralJson.set("feedbacks.logs", canalID);
        
                    await interaction.editReply({ content: `✅・O canal ${canalMencionado} foi definido como logs de feedbacks com sucesso!`, ephemeral: true });
                } else if (message.content.toLowerCase() === "remover") {
                    await GeneralJson.set("feedbacks.logs", "null");
                    await interaction.editReply({ content: `✅・O canal de logs feedbacks foi removido com sucesso!`, ephemeral: true });
                } else {
                    await interaction.editReply({ content: `❌・Marque um canal valido, ou digite "remover"!`, ephemeral: true });
                }
        
                collector.stop();
            });
        
            collector.on('end', collected => {
                if (collected.size === 0) {
                    interaction.editReply({ content: `❌・O tempo para a resposta esgotou!`, ephemeral: true });
                }
            });
        }

    }
}
    
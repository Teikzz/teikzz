const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ModalBuilder, TextInputBuilder } = require("discord.js");
const { JsonDatabase } = require("wio.db");
const Mods = new JsonDatabase({ databasePath: "./DataBaseJson/moderacao.json" });
const { configuracao } = require("../../DataBaseJson/configuracao.json");

module.exports = {
    name: "interactionCreate",
    run: async (interaction, client) => {

        if (interaction.isButton() && interaction.customId === "back6") {

            const painel = new EmbedBuilder()
        .setAuthor({ name: `${interaction.user.username} - Painel de configuração`, iconURL: interaction.user.displayAvatarURL() })
        .setDescription(`Olá ${interaction.user},\n\nEste é o seu painel de configuração, um espaço especialmente projetado para você otimizar todos os sistemas do bot. Aqui, você terá total controle sobre sugestões e feedbacks, permitindo que ajuste cada detalhe para garantir uma experiência fluida e sem problemas. Aproveite essa oportunidade para personalizar suas configurações e fazer com que tudo funcione perfeitamente para você!`)
        .setColor("#95a5a6")

        const botaopainel = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
            .setLabel("Configurar Sistemas")
            .setEmoji("1292990181208490088")
            .setCustomId("configsistemas")
            .setStyle(1),
            new ButtonBuilder()
            .setLabel("Personalizar Painel")
            .setEmoji("1294463426093121536")
            .setCustomId("configpainel")
            .setStyle(2)
        )


        await interaction.update({ embeds: [painel], components: [botaopainel], ephemeral: true })

        }

        if (interaction.isButton() && interaction.customId === "configmod") {

            const embedconfigmod = new EmbedBuilder()
                .setAuthor({ name: `${interaction.user.username} - Moderações`, iconURL: interaction.user.displayAvatarURL() })
                .setColor("Blue")
                .addFields(
                    { 
                        name: "Cargo Automático", 
                        value: `${Mods.get("moderações.cargoautomatico") ? `<@&${Mods.get("moderações.cargoautomatico")}>` : `Não definido.`}` 
                    },
                    { 
                        name: "Cargo Temporário", 
                        value: `${Mods.get("moderações.cargotemporario") ? `<@&${Mods.get("moderações.cargotemporario")}>` : `Não definido.`}` 
                    }
                );

                const botaoconfigmod = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                    .setLabel("Cargo Automático")
                    .setEmoji("1293361144190341163")
                    .setCustomId("cargoautomatico")
                    .setStyle(2),
                    new ButtonBuilder()
                    .setLabel("Cargo Temporário")
                    .setEmoji("1293361144190341163")
                    .setCustomId("cargotemporario")
                    .setStyle(2)
                )

                const botaoconfigmod2 = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                    .setLabel("Voltar")
                    .setEmoji("1269966035575115811")
                    .setCustomId("moderacaoslatestebot")
                    .setStyle(1)
                )

            await interaction.update({ embeds: [embedconfigmod], components: [botaoconfigmod, botaoconfigmod2], ephemeral: true });
        }

        if (interaction.isButton() && interaction.customId === "boasvindas") {

        const modal = new ModalBuilder()
        .setCustomId("boasvindas3")
        .setTitle("Configurar Boas Vindas");

        const canal = new TextInputBuilder()
        .setCustomId("canalid")
        .setLabel("👋 Canal para Boas Vindas")
        .setStyle(1)
        .setRequired(true)
            
        const tempo = new TextInputBuilder()
        .setCustomId("tempomsg")
        .setLabel("🔥 Tempo que as msg sera apagada")
        .setPlaceholder(`EM SEGUNDOS`)
        .setStyle(1)
        .setRequired(true)

        modal.addComponents(
            new ActionRowBuilder().addComponents(canal),
            new ActionRowBuilder().addComponents(tempo)
        );

        await interaction.showModal(modal);
    }

    if (interaction.isModalSubmit() && interaction.customId === "boasvindas3") {

        const canal = interaction.fields.getTextInputValue("canalid");
        const tempo = interaction.fields.getTextInputValue("tempomsg", 10);

        if (isNaN(tempo) || tempo <= 0) {
            return interaction.reply({ content: "Por favor, insira um valor de tempo válido em segundos.", ephemeral: true });
        }
        try {

            const canalDestino = interaction.guild.channels.cache.get(canal);

        if (!canalDestino) {
            return interaction.reply({ content: "Canal não encontrado.", ephemeral: true });
        }

        Mods.set("boasvindas.canal", canal)
        Mods.set("boasvindas.tempo", tempo * 1000)

        const embedconfigmod = new EmbedBuilder()
        .setColor(`#0cd4cc`)
        .setTitle(`Moderação`)
        .setDescription(`Bem-vindo ao seu Painel de Moderação, onde você pode configurar adicionais ao seu servidor.`)
        .addFields(
          { 
            name: "Boas Vindas", 
            value: `- Canal: ${Mods.get("boasvindas.canal") ? `<#${Mods.get("boasvindas.canal")}>` : `Não definido.` }\n` + 
                    `- Mensagem: ${Mods.get("boasvindas.mensagem") ? `${Mods.get("boasvindas.mensagem")}` : `Não definido.`}\n` + 
                    `- Tempo para apagar: ${Mods.get("boasvindas.tempo") ? `${Mods.get("boasvindas.tempo")}` : `Não definido.`}` 
        }
        )
        .setFooter(
          { text: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) }
        )
        .setTimestamp();
    
      const row2 = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
            .setCustomId("configsistemas")
            .setLabel('Sistema de Sugestão')
            .setEmoji(`1298916047860137997`)
            .setStyle(1)
            .setDisabled(false),
          new ButtonBuilder()
            .setCustomId("configmod")
            .setLabel('Roles Actions')
            .setEmoji(`1294486546170384485`)
            .setStyle(1)
            .setDisabled(false),
          new ButtonBuilder()
            .setCustomId("painelconfigbv") //aqui
            .setLabel('Boas Vindas')
            .setEmoji(`1238709839685746758`)
            .setStyle(1)
            .setDisabled(false)
        )

            await interaction.update({ embeds: [embedconfigmod], components: [row2], ephemeral: true })
           await interaction.followUp({ content: `Mensagem programada para ser enviada em ${tempo} segundos no canal ${canalDestino}.`, ephemeral: true })
            
        } catch (thzzrei) {
            console.log(thzzrei)
            return interaction.reply({ content: "Ocorreu um erro ai", ephemeral: true })
        }

    }

    if (interaction.isButton() && interaction.customId === "cargoautomatico") {
        const modal = new ModalBuilder()
            .setCustomId("cargoauto")
            .setTitle("Configurar Cargo Automático");
    
        const cargo = new TextInputBuilder()
            .setCustomId("cargoid")
            .setLabel("😍 ID do cargo para auto role")
            .setStyle(1)
            .setRequired(true);
    
        const thzz = new ActionRowBuilder().addComponents(cargo);
    
        modal.addComponents(thzz);
    
        await interaction.showModal(modal);
    }
    
    if (interaction.isModalSubmit() && interaction.customId === "cargoauto") {
        const cargoId = interaction.fields.getTextInputValue("cargoid");
    
        try {
            const cargo = interaction.guild.roles.cache.get(cargoId);
            
            if (!cargo) {
                return interaction.reply({ content: "ID de cargo inválido. Por favor, insira um ID de cargo válido.", ephemeral: true });
            }
    
            Mods.set("moderações.cargoautomatico", cargoId);
    
            const embedconfigmod = new EmbedBuilder()
                .setAuthor({ name: `${interaction.user.username} - Moderações`, iconURL: interaction.user.displayAvatarURL() })
                .setColor("Blue")
                .addFields(
                    { 
                        name: "Cargo Automático", 
                        value: `${Mods.get("moderações.cargoautomatico") ? `<@&${Mods.get("moderações.cargoautomatico")}>` : `Não definido.`}` 
                    },
                    { 
                        name: "Cargo Temporário", 
                        value: `${Mods.get("moderações.cargotemporario") ? `<@&${Mods.get("moderações.cargotemporario")}>` : `Não definido.`}` 
                    }
                );

                const botaoconfigmod = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                    .setLabel("Boas Vindas")
                    .setEmoji("1293361144190341163")
                    .setCustomId("boasvindas")
                    .setStyle(2),
                    new ButtonBuilder()
                    .setLabel("Cargo Automático")
                    .setEmoji("1293361144190341163")
                    .setCustomId("cargoautomatico")
                    .setStyle(2),
                    new ButtonBuilder()
                    .setLabel("Cargo Temporário")
                    .setEmoji("1293361144190341163")
                    .setCustomId("cargotemporario")
                    .setStyle(2),
                    new ButtonBuilder()
                    .setLabel("Antilink (ON/OFF)")
                    .setEmoji(Mods.get("moderações.antilink") ? "1295604569933348864" : "1295604602456244228")
                    .setCustomId("antilinkonoff")
                    .setStyle(Mods.get("moderações.antilink") ? 3 : 4)
                )

                const botaoconfigmod2 = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                    .setLabel("Voltar")
                    .setEmoji("1269966035575115811")
                    .setCustomId("back6")
                    .setStyle(1)
                )

            await interaction.update({ embeds: [embedconfigmod], components: [botaoconfigmod, botaoconfigmod2], ephemeral: true })
            await interaction.followUp({ content: `Cargo automático configurado com sucesso: <@&${cargoId}>`, ephemeral: true });
        } catch (error) {
            console.log(error);
            return interaction.reply({ content: "Ocorreu um erro ao configurar o cargo automático.", ephemeral: true });
        }
    }

    if (interaction.isButton() && interaction.customId === "cargotemporario") {
        const modal = new ModalBuilder()
            .setCustomId("cargotemp")
            .setTitle("Configurar Cargo Temporário");
    
        const cargo = new TextInputBuilder()
            .setCustomId("cargoidtemp")
            .setLabel("😍 ID do cargo temporário")
            .setStyle(1)
            .setRequired(true);
    
        const tempo = new TextInputBuilder()
            .setCustomId("tempocargo")
            .setLabel("⏳ Tempo em segundos para remover o cargo")
            .setStyle(1)
            .setRequired(true);
    
        const row1 = new ActionRowBuilder().addComponents(cargo);
        const row2 = new ActionRowBuilder().addComponents(tempo);
    
        modal.addComponents(row1, row2);
    
        await interaction.showModal(modal);
    }
    
    if (interaction.isModalSubmit() && interaction.customId === "cargotemp") {
        const cargoId = interaction.fields.getTextInputValue("cargoidtemp");
        const tempoSegundos = parseInt(interaction.fields.getTextInputValue("tempocargo"), 10);
    
        try {
            const cargo = interaction.guild.roles.cache.get(cargoId);
            
            if (!cargo) {
                return interaction.reply({ content: "ID de cargo inválido. Por favor, insira um ID de cargo válido.", ephemeral: true });
            }
    
            if (isNaN(tempoSegundos) || tempoSegundos <= 0) {
                return interaction.reply({ content: "Por favor, insira um tempo válido em segundos.", ephemeral: true });
            }
    
            Mods.set("moderações.cargotemporario", cargoId);
            Mods.set("moderações.tempoTemporario", tempoSegundos * 1000);
    
            const embedconfigmod = new EmbedBuilder()
                .setAuthor({ name: `${interaction.user.username} - Moderações`, iconURL: interaction.user.displayAvatarURL() })
                .setColor("Blue")
                .addFields(
                    { 
                        name: "Cargo Automático", 
                        value: `${Mods.get("moderações.cargoautomatico") ? `<@&${Mods.get("moderações.cargoautomatico")}>` : `Não definido.`}` 
                    },
                    { 
                        name: "Cargo Temporário", 
                        value: `${Mods.get("moderações.cargotemporario") ? `<@&${Mods.get("moderações.cargotemporario")}>` : `Não definido.`}` 
                    }
                );

                const botaoconfigmod = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                    .setLabel("Boas Vindas")
                    .setEmoji("1293361144190341163")
                    .setCustomId("boasvindas")
                    .setStyle(2),
                    new ButtonBuilder()
                    .setLabel("Cargo Automático")
                    .setEmoji("1293361144190341163")
                    .setCustomId("cargoautomatico")
                    .setStyle(2),
                    new ButtonBuilder()
                    .setLabel("Cargo Temporário")
                    .setEmoji("1293361144190341163")
                    .setCustomId("cargotemporario")
                    .setStyle(2),
                    new ButtonBuilder()
                    .setLabel("Antilink (ON/OFF)")
                    .setEmoji(Mods.get("moderações.antilink") ? "1295604569933348864" : "1295604602456244228")
                    .setCustomId("antilinkonoff")
                    .setStyle(Mods.get("moderações.antilink") ? 3 : 4)
                )

                const botaoconfigmod2 = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                    .setLabel("Voltar")
                    .setEmoji("1269966035575115811")
                    .setCustomId("back6")
                    .setStyle(1)
                )

            await interaction.update({ embeds: [embedconfigmod], components: [botaoconfigmod, botaoconfigmod2], ephemeral: true })
            await interaction.followUp({ content: `Cargo temporário configurado com sucesso: <@&${cargoId}>. Ele será removido em ${tempoSegundos} segundos.`, ephemeral: true });
        } catch (error) {
            console.log(error);
            return interaction.reply({ content: "Ocorreu um erro ao configurar o cargo temporário.", ephemeral: true });
        }
    }

    if(interaction.isButton() && interaction.customId === "antilinkonoff") {

        const statusAtual = Mods.get("moderações.antilink");
    
    const novoStatus = !statusAtual;

    Mods.set("moderações.antilink", novoStatus);

    const embedconfigmod = new EmbedBuilder()
                .setAuthor({ name: `${interaction.user.username} - Moderações`, iconURL: interaction.user.displayAvatarURL() })
                .setColor("Blue")
                .addFields(
                    { 
                        name: "Cargo Automático", 
                        value: `${Mods.get("moderações.cargoautomatico") ? `<@&${Mods.get("moderações.cargoautomatico")}>` : `Não definido.`}` 
                    },
                    { 
                        name: "Cargo Temporário", 
                        value: `${Mods.get("moderações.cargotemporario") ? `<@&${Mods.get("moderações.cargotemporario")}>` : `Não definido.`}` 
                    }
                );

        const botaoconfigmod = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                    .setLabel("Boas Vindas")
                    .setEmoji("1293361144190341163")
                    .setCustomId("boasvindas")
                    .setStyle(2),
                    new ButtonBuilder()
                    .setLabel("Cargo Automático")
                    .setEmoji("1293361144190341163")
                    .setCustomId("cargoautomatico")
                    .setStyle(2),
                    new ButtonBuilder()
                    .setLabel("Cargo Temporário")
                    .setEmoji("1293361144190341163")
                    .setCustomId("cargotemporario")
                    .setStyle(2),
                    new ButtonBuilder()
                    .setLabel("Antilink (ON/OFF)")
                    .setEmoji(novoStatus ? "1295604569933348864" : "1295604602456244228")
                    .setCustomId("antilinkonoff")
                    .setStyle(novoStatus ? 3 : 4)
                )

                const botaoconfigmod2 = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                    .setLabel("Voltar")
                    .setEmoji("1269966035575115811")
                    .setCustomId("back6")
                    .setStyle(1)
                )

            await interaction.update({ embeds: [embedconfigmod], components: [botaoconfigmod, botaoconfigmod2], ephemeral: true })

    }

        }

    }
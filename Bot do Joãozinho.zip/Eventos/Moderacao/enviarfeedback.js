const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ModalBuilder, TextInputBuilder, StringSelectMenuBuilder } = require("discord.js");
const { JsonDatabase } = require("wio.db");
const GeneralJson = new JsonDatabase({ databasePath: "./DataBaseJson/moderacao.json" })
const Feedbacks = new JsonDatabase({ databasePath: "./DataBaseJson/Feedbacks.json", autoWrite: true })

module.exports = {
    name: "interactionCreate",
    run: async (interaction, client) => {
        if (interaction.isStringSelectMenu() && interaction.customId === "selectMenuFeedbackSugestao") { 
            
            const selectedValue = interaction.values[0];

            if (selectedValue === "feedbacks_opcao") {
               
                const FeedbacksAtivo = GeneralJson.get("feedbacks.ativo")
                const FeedbacksCargo = GeneralJson.get("feedbacks.cargo")

                if (FeedbacksAtivo === false) {
                    return interaction.reply({ content: "❌・Feedbacks está temporariamente inativo, volte outra hora!", ephemeral: true });
                }

                if (FeedbacksCargo !== "null" && !interaction.member.roles.cache.has(FeedbacksCargo)) {
                    return interaction.reply({ content: `❌・Você não possui o cargo de <@&${FeedbacksCargo}> para realizar esta ação!`, ephemeral: true });
                }

                const modal = new ModalBuilder()
                .setCustomId("enviofeedback")
                .setTitle("Seu Feedback sobre o Servidor");
    
                const estrela = new TextInputBuilder()
                .setCustomId("estrelasfeedback")
                .setLabel("⭐ Quantas estrelas? (1 a 5)")
                .setMaxLength(1)
                .setPlaceholder("Nota para a avaliação")
                .setRequired(true)
                .setStyle(1)

                const avaliacao = new TextInputBuilder()
                .setCustomId("avaliacaofeedback")
                .setLabel("✏️ Sua avaliação? (OPCIONAL)")
                .setRequired(false)
                .setPlaceholder("Mensagem para a avaliação")
                .setStyle(1)
    
             modal.addComponents(
                new ActionRowBuilder().addComponents(estrela),
                new ActionRowBuilder().addComponents(avaliacao)
            );
    
            await interaction.showModal(modal);
        }

        }

        if (interaction.isModalSubmit() && interaction.customId === "enviofeedback") {

            const estrelas = interaction.fields.getTextInputValue("estrelasfeedback");
            const avaliação = interaction.fields.getTextInputValue("avaliacaofeedback") || "Nenhuma avaliação enviada..."

            const estrelasNumber = parseInt(estrelas, 10);
            if (isNaN(estrelasNumber) || estrelasNumber < 1 || estrelasNumber > 5) {
                return interaction.reply({ content: "❌・Você so pode enviar estrelas entre 1 é 5.", ephemeral: true });
            }

            const estrelasEmoji = "⭐".repeat(estrelasNumber)

            const logsfeedbacksID = GeneralJson.get("feedbacks.logs")

            if (logsfeedbacksID === "null") {
                return interaction.reply({ content: "❌・Não possuo uma logs para os feedbacks, peça ajuda a algum administrador!", ephemeral: true });
            }

            const logsfeedbacks = interaction.guild.channels.cache.get(logsfeedbacksID);
            
            if (!logsfeedbacks) {
                return interaction.reply({ content: "❌・Não consegui encontrar o canal de logs, peça ajuda a algum administrador!", ephemeral: true });
            }

            const totalFeedbacks = GeneralJson.get("feedbacks.total_feedbacks");
            const novosFeedbacks = totalFeedbacks + 1;
            GeneralJson.set("feedbacks.total_feedbacks", novosFeedbacks);
            const porcentagem = Math.min(Math.floor((novosFeedbacks / 100) * 100), 100);
            const timestampUnix = Math.floor(Date.now() / 1000);

            const botaoirpainel = new ActionRowBuilder()
            .addComponents(
            new ButtonBuilder()
                .setLabel("Ir para o painel")
                .setURL(`https://discord.com/channels/${interaction.guild.id}/${GeneralJson.get("painel.canalid")}/${GeneralJson.get("mensagemid")}`)
                .setStyle(5)
         );

            const embedfeedbacks = new EmbedBuilder()
            .setTitle(`<a:CD_estrelas:1296197008247488585> | Nova Avaliação (${novosFeedbacks})`)
            .addFields(
                { name: "<:cliente:1293738392726540349> | Usuário que enviou:", value: `\`${interaction.user.username} (${interaction.user.id})\`` },
                { name: "<:etiqueta_StorM:1293382915429761126> | Porcentagem de Feedbacks:", value: `\`${porcentagem}%\`` },
                { name: "<a:estrela:1296198793833746432> | Nota:", value: `${estrelasEmoji} (${estrelas}/5)` },
                { name: "<:prancheta:1294463165580443698> | Avaliação:", value: `\`${avaliação}\`` },
                { name: "<:emoji_48:1293739649801519126> | Data / Horário:", value: `<t:${timestampUnix}:f> (<t:${timestampUnix}:R>)` }
            )
            .setColor("Green")

            await logsfeedbacks.send({ content: `${interaction.user}`, embeds: [embedfeedbacks], components: [botaoirpainel] })

            const botaoirfeedback = new ActionRowBuilder()
            .addComponents(
            new ButtonBuilder()
                .setLabel("Ir para a mensagem")
                .setURL(`https://discord.com/channels/${interaction.guild.id}/${logsfeedbacks.id}/${embedfeedbacks.id}`)
                .setStyle(5)
            );

            await interaction.reply({ content: "✅・Feedback enviado com sucesso!", components: [botaoirfeedback], ephemeral: true });

            const selectMenuPainel = new StringSelectMenuBuilder()
        .setCustomId("selectMenuFeedbackSugestao")
        .setPlaceholder("Selecione uma opção")
        .addOptions(
            {
                label: "Sugestões",
                description: "Envie sugestões para a melhoria do servidor.",
                emoji: "1284568367461826664",
                value: "sugestoes_opcao"
            },
            {
                label: "Feedbacks",
                description: "Faça uma avaliação sobre o servidor.",
                emoji: "1284568251057180794",
                value: "feedbacks_opcao"
            }
        );

    const row = new ActionRowBuilder().addComponents(selectMenuPainel);

    const painelMessageId = GeneralJson.get("painel.mensagemid");
    const painelChannelId = GeneralJson.get("painel.canalid");

    const channel = interaction.guild.channels.cache.get(painelChannelId);
    if (channel) {
        try {
            const painelMessage = await channel.messages.fetch(painelMessageId);
            await painelMessage.edit({ components: [row] });
        } catch (error) {
            console.error('Erro ao atualizar o painel:', error);
        }
    }

        }

        
                
            }
        }

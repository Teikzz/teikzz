const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ModalBuilder, TextInputBuilder, StringSelectMenuBuilder } = require("discord.js");
const { JsonDatabase } = require("wio.db");
const GeneralJson = new JsonDatabase({ databasePath: "./DataBaseJson/moderacao.json" });
const SugestoesDB = new JsonDatabase({ databasePath: "./DataBaseJson/Sugestões.json", autoWrite: true });
const Votos = new JsonDatabase({ databasePath: "./DataBaseJson/VotosSugestões.json", autoWrite: true });
let teste = ""
let teste2 = ""
module.exports = {
    name: "interactionCreate",
    run: async (interaction, client) => {

        if (interaction.isStringSelectMenu() && interaction.customId === "selectMenuFeedbackSugestao") { 
            const selectedValue = interaction.values[0];

            if (selectedValue === "sugestoes_opcao") {
                const SugestoesAtivo = GeneralJson.get("sugestao.ativo");
                const SugestoesCargo = GeneralJson.get("sugestao.cargo");

                if (SugestoesAtivo === false) {
                    return interaction.reply({ content: "❌・Sugestões estão temporariamente inativas, tente mais tarde!", ephemeral: true });
                }

                if (SugestoesCargo !== "null" && !interaction.member.roles.cache.has(SugestoesCargo)) {
                    return interaction.reply({ content: `❌・Você precisa do cargo <@&${SugestoesCargo}> para fazer uma sugestão!`, ephemeral: true });
                }

                const modal = new ModalBuilder()
                    .setCustomId("enviosugestao")
                    .setTitle("Sua Sugestão");

                const titulo = new TextInputBuilder()
                    .setCustomId("titulosugestao")
                    .setLabel("✏️ Título da Sugestão")
                    .setPlaceholder("Informe o título...")
                    .setStyle(1)
                    .setRequired(true);

                const desc = new TextInputBuilder()
                    .setCustomId("descsugestao")
                    .setLabel("✏️ Descrição")
                    .setPlaceholder("Descreva sua sugestão...")
                    .setStyle(2)
                    .setRequired(true);

                const imagem = new TextInputBuilder()
                    .setCustomId("imagemsugestao")
                    .setLabel("✏️ Imagem (Opcional)")
                    .setPlaceholder("Informe a URL da imagem (opcional)...")
                    .setStyle(1)
                    .setRequired(false);

                modal.addComponents(
                    new ActionRowBuilder().addComponents(titulo),
                    new ActionRowBuilder().addComponents(desc),
                    new ActionRowBuilder().addComponents(imagem)
                );

                await interaction.showModal(modal);
            }
        }

        if (interaction.isModalSubmit() && interaction.customId === "enviosugestao") {
            teste = interaction.fields.getTextInputValue("titulosugestao");
            teste2 = interaction.fields.getTextInputValue("descsugestao");
            const imagemvalidar = interaction.fields.getTextInputValue("imagemsugestao");
            let imagem;

            if (imagemvalidar) {
                try {
                    const url = new URL(imagemvalidar);
                    imagem = url.href;
                } catch {
                    return await interaction.reply({ content: "❌・URL da imagem é inválida!", ephemeral: true });
                }
            }

            let respostaImagem = imagem ? imagem : "Nenhuma imagem enviada...";
            let imagemembed = imagem || null;

            const userSugestoes = SugestoesDB.get(interaction.user.id) || { sugestoes: [] };
            userSugestoes.sugestoes.push({
                titulo: teste,
                descricao: teste2,
                imagem: respostaImagem
            });
            SugestoesDB.set(interaction.user.id, userSugestoes);

            const logssugestoesID = GeneralJson.get("sugestao.logs");

            if (logssugestoesID === "null") {
                return interaction.reply({ content: "❌・Canal de logs para sugestões não configurado!", ephemeral: true });
            }

            const logssugestoes = interaction.guild.channels.cache.get(logssugestoesID);
            if (!logssugestoes) {
                return interaction.reply({ content: "❌・Não encontrei o canal de logs, peça ajuda ao administrador!", ephemeral: true });
            }

            let totalpessoas_favor = 0;
            let totalpessoas_contra = 0;

            const totalVotos = totalpessoas_favor + totalpessoas_contra;
            const porcentagem_favor = totalVotos > 0 ? Math.round((totalpessoas_favor / totalVotos) * 100) : 0;
            const porcentagem_contra = totalVotos > 0 ? Math.round((totalpessoas_contra / totalVotos) * 100) : 0;

            const embedsugestoes = new EmbedBuilder()
                .setAuthor({ name: `${interaction.user.username} (${interaction.user.id})`, iconURL: interaction.user.displayAvatarURL() })
                .setTitle(`${teste}`)
                .setDescription(`\`\`\`${teste2}\`\`\``)
                .setImage(imagemembed);

            const botaovotaçãosugestao = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setLabel(`・${totalpessoas_favor} - (${porcentagem_favor}%)`)
                        .setEmoji("1296264136283521109")
                        .setCustomId("sugestaofavor")
                        .setStyle(3),
                    new ButtonBuilder()
                        .setLabel(`・${totalpessoas_contra} - (${porcentagem_contra}%)`)
                        .setEmoji("1296264168940376085")
                        .setCustomId("sugestaocontra")
                        .setStyle(4)
                );

            const mensagemEnviada = await logssugestoes.send({ content: `${interaction.user}`, embeds: [embedsugestoes], components: [botaovotaçãosugestao] });

            setTimeout(async () => {

                const owner = await interaction.guild.fetchOwner();
                const embedEncerramento = new EmbedBuilder()
                .setAuthor({ name: `${owner.user.username} - Auto Encerramento de Sugestão`, iconURL: owner.user.displayAvatarURL() })
                .setDescription(`# <:ReportS_StorM:1292990875454013600> Sugestão Encerrada\nAtenção, <@${owner.id}>!\n- Devido à implementação do nosso sistema de **auto encerramento de sugestões**, esta sugestão foi encerrada após 24 horas, acreditamos que é uma medida necessária para mantermos a organização. Agradecemos por compartilhar sua ideia, e sua voz é importante para nós!`)
                .addFields(
                    { name: "Titulo da Sugestão:", value: `\`\`\`${teste}\`\`\`` },
                    { name: "Descrição da Sugestão:", value: `\`\`\`${teste2}\`\`\`` },
                    { name: "Imagem da Sugestão:", value: `${respostaImagem}` }
                )
    
                await mensagemEnviada.edit({ content: `Dono da Sugestão: ${interaction.user}`, embeds: [embedEncerramento], components: [] });
    
                thread.delete()
            }, 86400000);

          const thread = await mensagemEnviada.startThread({
                name: `Debater Sugestão - ${teste}`,
                autoArchiveDuration: 1440,
                reason: "Criada para discussão sobre a sugestão."
            });

            thread.send(`${interaction.user}, agradeçemos por compartilhar sua sugestão! 🌟\n\n> Fique à vontade para adicionar mais informações ou discutir sobre a sugestão. Seu feedback é muito valioso para nós! 💬`)

            const botaoIrSugestao = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setLabel("Ir para a mensagem")
                        .setURL(`https://discord.com/channels/${interaction.guild.id}/${logssugestoes.id}/${mensagemEnviada.id}`)
                        .setStyle(5)
                );

            await interaction.reply({ content: "✅・Sugestão enviada com sucesso!", components: [botaoIrSugestao], ephemeral: true });
        }

        const selectMenuPainel = new StringSelectMenuBuilder()
        .setCustomId("selectMenuFeedbackSugestao")
        .setPlaceholder("Selecione uma opção")
        .addOptions(
            {
                label: "Sugestões",
                description: "Envie sugestões para a melhoria do servidor.",
                emoji: "1284568367461826664",
                value: "sugestoes_opcao"
            },
            {
                label: "Feedbacks",
                description: "Faça uma avaliação sobre o servidor.",
                emoji: "1284568251057180794",
                value: "feedbacks_opcao"
            }
        );

    const row = new ActionRowBuilder().addComponents(selectMenuPainel);

    const painelMessageId = GeneralJson.get("painel.mensagemid");
    const painelChannelId = GeneralJson.get("painel.canalid");

   if (interaction.guild) {
    const channel = interaction.guild.channels.cache.get(painelChannelId);
    if (channel) {
        try {
            const painelMessage = await channel.messages.fetch(painelMessageId);
            await painelMessage.edit({ components: [row] });
        } catch (error) {
            console.error('Erro ao atualizar o painel:', error);
        }
    } else {
    }
} else {
    console.error("Guild não encontrada.");
}



        if(interaction.isButton() && interaction.customId === "sugestaofavor") {
            const sugestaoID = interaction.message.id;
            let votos = Votos.get(sugestaoID) || { favor: [], contra: [] };
            let msgreply = ""

            if (votos.favor.includes(interaction.user.id)) {
                votos.favor = votos.favor.filter(id => id !== interaction.user.id);
                msgreply = "✅ Voto Retirado!"
            } else {
                if (votos.contra.includes(interaction.user.id)) {
                    votos.contra = votos.contra.filter(id => id !== interaction.user.id);
                }
                votos.favor.push(interaction.user.id);
                msgreply = "✅ Voto Adicionado!"
            }

            const totalVotos = votos.favor.length + votos.contra.length;
            const porcentagem_favor = totalVotos > 0 ? Math.round((votos.favor.length / totalVotos) * 100) : 0;
            const porcentagem_contra = totalVotos > 0 ? Math.round((votos.contra.length / totalVotos) * 100) : 0;

            const botaovotaçãosugestaoAtualizado = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setLabel(`・${votos.favor.length} - (${porcentagem_favor}%)`)
                        .setEmoji("1296264136283521109")
                        .setCustomId("sugestaofavor")
                        .setStyle(3),
                    new ButtonBuilder()
                        .setLabel(`・${votos.contra.length} - (${porcentagem_contra}%)`)
                        .setEmoji("1296264168940376085")
                        .setCustomId("sugestaocontra")
                        .setStyle(4)
                );

            await interaction.update({ components: [botaovotaçãosugestaoAtualizado] });
            await interaction.followUp({ content: msgreply, ephemeral: true });
            Votos.set(sugestaoID, votos);
        }

        if(interaction.isButton() && interaction.customId === "sugestaocontra") {
            const sugestaoID = interaction.message.id;
            let votos = Votos.get(sugestaoID) || { favor: [], contra: [] };
            let msgreply = ""

            if (votos.contra.includes(interaction.user.id)) {
                votos.contra = votos.contra.filter(id => id !== interaction.user.id);
                msgreply = "✅ Voto Retirado!"
            } else {
                if (votos.favor.includes(interaction.user.id)) {
                    votos.favor = votos.favor.filter(id => id !== interaction.user.id);
                }

                votos.contra.push(interaction.user.id);
                msgreply = "✅ Voto Adicionado!"
            }

            const totalVotos = votos.favor.length + votos.contra.length;
            const porcentagem_favor = totalVotos > 0 ? Math.round((votos.favor.length / totalVotos) * 100) : 0;
            const porcentagem_contra = totalVotos > 0 ? Math.round((votos.contra.length / totalVotos) * 100) : 0;

            const botaovotaçãosugestaoAtualizado = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setLabel(`・${votos.favor.length} - (${porcentagem_favor}%)`)
                        .setEmoji("1296264136283521109")
                        .setCustomId("sugestaofavor")
                        .setStyle(3),
                    new ButtonBuilder()
                        .setLabel(`・${votos.contra.length} - (${porcentagem_contra}%)`)
                        .setEmoji("1296264168940376085")
                        .setCustomId("sugestaocontra")
                        .setStyle(4)
                );
  

            await interaction.update({ components: [botaovotaçãosugestaoAtualizado] });
            await interaction.followUp({ content: msgreply, ephemeral: true });
            Votos.set(sugestaoID, votos);

        }
        
    }
};

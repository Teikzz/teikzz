const {
    EmbedBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
} = require("discord.js");
const fs = require('fs');
const path = require('path');
const { configuracao } = require('../../DataBaseJson');

// Caminho do arquivo de configuração
const configPath = path.resolve(__dirname, '../../DataBaseJson/proteçaoconfig.json');

// Função para carregar a configuração
const loadConfig = () => {
    try {
        const rawConfig = fs.readFileSync(configPath);
        return JSON.parse(rawConfig);
    } catch (error) {
        console.error('Erro ao carregar a configuração:', error);
        return { proteção: { bloquearLinks: false, bloquearPalavras: false, backupServidor: false } };
    }
};

// Função para salvar a configuração
const saveConfig = (config) => {
    try {
        fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
    } catch (error) {
        console.error('Erro ao salvar a configuração:', error);
    }
};

// Função para atualizar a configuração
const updateConfig = (newConfig) => {
    const config = loadConfig();
    config.proteção = { ...config.proteção, ...newConfig };
    saveConfig(config);
};

// Função para atualizar a mensagem do painel
const updatePanelMessage = async (interaction) => {
    const config = loadConfig().proteção;

    const embed = new EmbedBuilder()
        .setDescription(`## Proteção do Servidor \n- Olá ${interaction.user}, segue abaixo as informações sobre o sistema de Proteção.`)
        .addFields(
            { name: 'Bloquear Links', value: config.bloquearLinks ? '\`\`Ativado\`\`' : '\`\`Desativado\`\`', inline: true },
            { name: 'Bloquear Palavras', value: config.bloquearPalavras ? '\`\`Ativado\`\`' : '\`\`Desativado\`\`', inline: true },
            { name: 'Backup de Mensagens', value: config.backupServidor ? '\`\`Ativado\`\`' : '\`\`Desativado\`\`', inline: true }
        )
        .setColor(configuracao.get('Cores.Principal') || '0cd4cc');

    const row = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId('toggleLinks')
                .setLabel(config.bloquearLinks ? 'Desativar Bloqueio de Links' : 'Ativar Bloqueio de Links')
                .setEmoji('1292614700194074689')
                .setStyle(config.bloquearLinks ? ButtonStyle.Danger : ButtonStyle.Success),
            new ButtonBuilder()
                .setCustomId('togglePalavras')
                .setLabel(config.bloquearPalavras ? 'Desativar Bloqueio de Palavras' : 'Ativar Bloqueio de Palavras')
                .setEmoji('1292614700194074689')
                .setStyle(config.bloquearPalavras ? ButtonStyle.Danger : ButtonStyle.Success),
            new ButtonBuilder()
                .setCustomId('toggleBackup')
                .setLabel(config.backupServidor ? 'Desativar Backup de Mensagens' : 'Ativar Backup de Mensagens')
                .setEmoji('1292614700194074689')
                .setStyle(config.backupServidor ? ButtonStyle.Danger : ButtonStyle.Success)
        );

    const actionRow2 = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId('voltar00')
                .setLabel('Voltar')
                .setEmoji('1285016405426835468')
                .setStyle(ButtonStyle.Secondary)
        );

    await interaction.update({ embeds: [embed], components: [row, actionRow2] });
};

module.exports = {
    name: 'interactionCreate',
    run: async (interaction, client) => {
        try {
            if (interaction.isButton()) {
                if (interaction.customId === 'protecaoserver') {
                    await updatePanelMessage(interaction);
                } else if (['toggleLinks', 'togglePalavras', 'toggleBackup'].includes(interaction.customId)) {
                    const config = loadConfig().proteção;
                    const updatedConfig = {
                        bloquearLinks: interaction.customId === 'toggleLinks' ? !config.bloquearLinks : config.bloquearLinks,
                        bloquearPalavras: interaction.customId === 'togglePalavras' ? !config.bloquearPalavras : config.bloquearPalavras,
                        backupServidor: interaction.customId === 'toggleBackup' ? !config.backupServidor : config.backupServidor,
                    };

                    updateConfig(updatedConfig);
                    await updatePanelMessage(interaction);
                } else if (interaction.customId === 'voltarautomaticos') {
                    await interaction.update({ content: 'Você voltou à configuração anterior.', components: [] });
                }
            }
        } catch (error) {
            console.error('Erro ao processar a interação:', error);
        }
    }
};

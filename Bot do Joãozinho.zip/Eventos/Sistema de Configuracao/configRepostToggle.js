const { ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require('discord.js');
const { configuracao, produtos } = require("../../DataBaseJson");
const { agendarRepostagem, pararRepostagem } = require("../../Functions/repostagem");
const moment = require('moment-timezone');

module.exports = {
    name: 'interactionCreate',

    run: async (interaction, client) => {
        if (!interaction.isButton()) return;

        if (interaction.customId === "desabilityRepost" || interaction.customId === "enableRepost") {
            const currentStatus = configuracao.get(`Repostagem.Status`);
            const newStatus = !currentStatus;

            configuracao.set(`Repostagem.Status`, newStatus);

            const updatedEmbed = await createUpdatedEmbed(interaction, client);
            const updatedRow = createUpdatedRow(newStatus);

            const statusText = newStatus ? 'habilitada' : 'desabilitada';
            const replyContent = `A função de repostagem foi ${statusText}. Novo status: ${newStatus ? 'Ativo' : 'Inativo'}`;

            await interaction.update({
                //content: replyContent,
                embeds: [updatedEmbed],
                components: [updatedRow],
            });

            console.log(`Repostagem ${statusText} por ${interaction.user.tag} (${interaction.user.id})`);

            if (newStatus) {
                agendarRepostagem(client);
            } else {
                pararRepostagem();
            }
        }
    }
};

async function createUpdatedEmbed(interaction, client) {
    const repostagemHora = configuracao.get(`Repostagem.Hora`) || "00:01";
    const currentStatus = configuracao.get(`Repostagem.Status`);
    const currentTime = moment.tz("America/Sao_Paulo");

    const [hours, minutes] = repostagemHora.split(':').map(Number);
    let nextExecutionTime = moment.tz("America/Sao_Paulo").set({ hour: hours, minute: minutes, second: 0, millisecond: 0 });

    if (nextExecutionTime.isBefore(currentTime)) {
        nextExecutionTime.add(1, 'day');
    }

    const nextExecutionTimestamp = Math.floor(nextExecutionTime.valueOf() / 1000);
    const todosProdutos = await produtos.all();

    return new EmbedBuilder()
    .setAuthor({ name: `${interaction.guild.name}`, iconURL: client.user.displayAvatarURL() }) // Nome do servidor e ícone do bot
    .setThumbnail(client.user.displayAvatarURL())
        .setColor(`${configuracao.get(`Cores.Principal`) == null ? '0cd4cc' : configuracao.get('Cores.Principal')}`)
        .setDescription(`## Repostagem Automática \n- Olá ${interaction.user}, segue abaixo as informações sobre o sistema de Repostagens de Produtos.`)
        .addFields(
            { name: `Quantidades de produtos em repostagens`, value: `\`${todosProdutos.length}\``, inline: true },
            { name: `Repostagem de Produtos`, value: currentStatus ? '`Ativado 🟢`' : '`Desativado 🔴`', inline: true },
            { name: `Próxima execução`, value: currentStatus ? `\`${nextExecutionTime.format('DD/MM/YYYY HH:mm:ss')}\`` : '`Desativado.`', inline: true },
            { name: `Tempo até a próxima execução`, value: currentStatus ? `<t:${nextExecutionTimestamp}:R>` : '`Desativado.`' },
        )
        .setFooter(
            { text: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) }
        )
        .setTimestamp();
}

function createUpdatedRow(currentStatus) {
    return new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
            .setCustomId(currentStatus ? "desabilityRepost" : "enableRepost")
            .setLabel(currentStatus ? 'Desabilitar função' : 'Habilitar função')
            .setEmoji(`1259569896472182784`)
            .setStyle(currentStatus ? ButtonStyle.Danger : ButtonStyle.Success),
            new ButtonBuilder()
                .setCustomId("setTimeRepost")
                .setLabel('Definir horário')
                .setEmoji('1241819612044197949')
                .setStyle(2)
                .setDisabled(!currentStatus),

        );
}
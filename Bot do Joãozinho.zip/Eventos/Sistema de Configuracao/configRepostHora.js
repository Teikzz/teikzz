const { ActionRowBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, InteractionType, EmbedBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { configuracao, produtos } = require("../../DataBaseJson");
const { agendarRepostagem } = require("../../Functions/repostagem");
const moment = require('moment-timezone');

module.exports = {
    name: 'interactionCreate',

    run: async (interaction, client) => {
        if (interaction.isButton()) {
            if (interaction.customId === 'setTimeRepost') {
                const modal = new ModalBuilder()
                    .setCustomId('timeRepostModal')
                    .setTitle('Definir Horário de Repostagem');

                const timeInput = new TextInputBuilder()
                    .setCustomId('timeInput')
                    .setLabel('Horário (HH:MM)')
                    .setStyle(TextInputStyle.Short)
                    .setPlaceholder('Ex: 14:30')
                    .setRequired(true);

                const actionRow = new ActionRowBuilder().addComponents(timeInput);
                modal.addComponents(actionRow);

                await interaction.showModal(modal);
            }
        }

        if (interaction.type === InteractionType.ModalSubmit) {
            if (interaction.customId === 'timeRepostModal') {
                await interaction.deferUpdate();

                const timeInput = interaction.fields.getTextInputValue('timeInput');
                const timeRegex = /^([01]\d|2[0-3]):([0-5]\d)$/;

                if (!timeRegex.test(timeInput)) {
                    await interaction.followUp({
                        content: '❌ Formato de horário inválido. Use o formato HH:MM.',
                        ephemeral: true
                    });
                    return;
                }

                configuracao.set(`Repostagem.Hora`, timeInput);

                agendarRepostagem(client);

                try {
                    const updatedEmbed = await createUpdatedEmbed(interaction, client);
                    const updatedRow = createUpdatedRow(configuracao.get(`Repostagem.Status`));

                    await interaction.editReply({
                        //content: `✅ | Horário de repostagem atualizado para ${timeInput}.`,
                        embeds: [updatedEmbed],
                        components: [updatedRow]
                    });
                } catch (error) {
                    console.error('Erro ao atualizar a mensagem:', error);
                    await interaction.followUp({
                        content: `✅ Horário de repostagem atualizado para ${timeInput}, mas não foi possível atualizar a mensagem original.`,
                        ephemeral: true
                    });
                }
            }
        }
    }
};

async function createUpdatedEmbed(interaction, client) {
    const repostagemHora = configuracao.get(`Repostagem.Hora`) || "00:01";
    const currentTime = moment.tz("America/Sao_Paulo");

    const [hours, minutes] = repostagemHora.split(':').map(Number);
    let nextExecutionTime = moment.tz("America/Sao_Paulo").set({ hour: hours, minute: minutes, second: 0, millisecond: 0 });

    if (nextExecutionTime.isBefore(currentTime)) {
        nextExecutionTime.add(1, 'day');
    }

    const nextExecutionTimestamp = Math.floor(nextExecutionTime.valueOf() / 1000);
    const currentStatus = configuracao.get(`Repostagem.Status`);
    const todosProdutos = await produtos.all();

    return new EmbedBuilder()
    .setAuthor({ name: `${interaction.guild.name}`, iconURL: client.user.displayAvatarURL() }) // Nome do servidor e ícone do bot
    .setThumbnail(client.user.displayAvatarURL())
        .setColor(`${configuracao.get(`Cores.Principal`) == null ? '0cd4cc' : configuracao.get('Cores.Principal')}`)
        .setDescription(`## Repostagem Automática \n- Olá ${interaction.user}, segue abaixo as informações sobre o sistema de Repostagens de Produtos.`)
        .addFields(
            { name: `Quantidades de produtos em repostagens`, value: `\`${todosProdutos.length}\``, inline: true },
            { name: `Repostagem de Produtos`, value: currentStatus ? '`Ativado 🟢`' : '`Desativado 🔴`', inline: true },
            { name: `Próxima execução`, value: currentStatus ? `\`${nextExecutionTime.format('DD/MM/YYYY HH:mm:ss')}\`` : '`Função desativada.`', inline: true },
            { name: `Tempo até a próxima execução`, value: currentStatus ? `<t:${nextExecutionTimestamp}:R>` : '`Função desativada.`' },
        )
        .setFooter(
            { text: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) }
        )
        .setTimestamp();
}

function createUpdatedRow(currentStatus) {
    return new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId(currentStatus ? "desabilityRepost" : "enableRepost")
                .setLabel(currentStatus ? 'Desabilitar função' : 'Habilitar função')
                .setEmoji(`1259569896472182784`)
                .setStyle(currentStatus ? ButtonStyle.Danger : ButtonStyle.Success),
            new ButtonBuilder()
                .setCustomId("setTimeRepost")
                .setLabel('Definir horário')
                .setEmoji(`1241819612044197949`)
                .setStyle(2)
                .setDisabled(false),
        );
}

const { ActionRowBuilder, StringSelectMenuBuilder, InteractionType } = require("discord.js");
const { msgsauto } = require("../../DataBaseJson");

module.exports = {
    name: 'interactionCreate',

    run: async (interaction, client) => {
        if (interaction.isButton()) {
            if (interaction.customId === 'removeAutomaticMessages') {
                const channelsData = msgsauto.get('channels') || [];
                const options = [];

                for (const channel of channelsData) {
                    try {
                        const discordChannel = await client.channels.fetch(channel.id);
                        if (discordChannel) {
                            options.push({
                                label: `${channel.message.slice(0, 60)}${channel.message.length > 60 ? '...' : ''}`,
                                description: `Canal: ${discordChannel.name}`,
                                value: channel.id
                            });
                        }
                    } catch (error) {
                        console.error(`Erro ao buscar canal: ${error}`);
                        options.push({
                            label: `Mensagem não encontrada...`,
                            description: `Canal não encontrado ou sem acesso`,
                            value: channel.id
                        });
                    }
                }

                const selectMenu = new StringSelectMenuBuilder()
                    .setCustomId('selectMessageToRemove')
                    .setPlaceholder('Escolha uma mensagem para remover')
                    .setMinValues(1)
                    .setMaxValues(1)
                    .addOptions(options);

                const row = new ActionRowBuilder().addComponents(selectMenu);
                await interaction.reply({
                    content: '⬇ Selecione a mensagem que deseja remover:',
                    components: [row],
                    ephemeral: true
                });
            }
        }

        if (interaction.isStringSelectMenu()) {
            if (interaction.customId === 'selectMessageToRemove') {
                const channelId = interaction.values[0];
                const channels = msgsauto.get('channels') || [];
                const channelIndex = channels.findIndex(c => c.id === channelId);

                if (channelIndex !== -1) {
                    channels.splice(channelIndex, 1);
                    msgsauto.set('channels', channels);
                    await interaction.update({
                        content: '✅ | Mensagem removida com sucesso!',
                        components: [],
                        ephemeral: true
                    }).catch(error => console.error('Erro ao enviar update:', error));
                } else {
                    await interaction.update({
                        content: 'A mensagem não foi encontrada no banco de dados.',
                        components: [],
                        ephemeral: true
                    }).catch(error => console.error('Erro ao enviar update:', error));
                }
            }
        }
    }
};

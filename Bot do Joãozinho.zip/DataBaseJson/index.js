const {
  JsonDatabase,
} = require("wio.db");


const produtos = new JsonDatabase({
  databasePath: "./DataBaseJson/produtos.json"
});

const buttons = new JsonDatabase({
  databasePath: "./DataBaseJson/buttons.json"
});

const carrinhos = new JsonDatabase({
  databasePath: "./DataBaseJson/carrinhos.json"
});

const pagamentos = new JsonDatabase({
  databasePath: "./DataBaseJson/pagamentos.json"
});

const pedidos = new JsonDatabase({
  databasePath: "./DataBaseJson/pedidos.json"
});

const estatisticas = new JsonDatabase({
  databasePath: "./DataBaseJson/estatisticas.json"
});

const configuracao = new JsonDatabase({
  databasePath: "./DataBaseJson/configuracao.json"
});

const tickets = new JsonDatabase({
  databasePath: "./DataBaseJson/tickets.json"
});

const perms = new JsonDatabase({
  databasePath: "./DataBaseJson/perms.json"
});

const msgsauto = new JsonDatabase({
  databasePath: "./DataBaseJson/msgsauto.json"
});

const config = new JsonDatabase({
  databasePath: "./DataBaseJson/config.json"
});

const users = new JsonDatabase({
  databasePath: "./DataBaseJson/users.json"
});
const ussers = new JsonDatabase({
  databasePath: "./DataBaseJson/ussers.json"
});

const conffig = new JsonDatabase({
  databasePath: "./DataBaseJson/conffig.json"
});

const configauth = new JsonDatabase({
  databasePath: "./DataBaseJson/configauth.json"
});
const usersauth = new JsonDatabase({
  databasePath: "./DataBaseJson/usersauth.json"
});

module.exports = {
  produtos,
  buttons,
  carrinhos,
  pagamentos,
  pedidos,
  configuracao,
  estatisticas,
  tickets,
  perms,
  msgsauto,
  config,
  users,
  ussers,
  conffig,
  configauth,
  usersauth
}
const { GatewayIntentBits, Client, Collection, ChannelType } = require("discord.js")
const { AtivarIntents } = require("./Functions/StartIntents");
const { configuracao, carrinhos } = require("./DataBaseJson");
const { handleDeletedMessage, handleUpdatedMessage } = require('./Functions/MsgsLogs');
const { handleVoiceStateUpdate } = require('./Functions/VoiceLogs');
const { handleProfileUpdate } = require('./Functions/ProfileLog');
const { agendarRepostagem } = require('./Functions/repostagem');
const schedule = require('node-schedule');
const fs = require('fs');
const path = require('path');
const colors = require("colors")
const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildVoiceStates,
        GatewayIntentBits.DirectMessages,
        GatewayIntentBits.GuildMessageReactions
    ]
});

const estatisticasKingInstance = require("./Functions/VariaveisEstatisticas");
const EstatisticasKing = new estatisticasKingInstance();
module.exports = { EstatisticasKing }
const { sendMessage } = require('./Functions/MsgAutomatics');

AtivarIntents()

const config = require("./config.json");
const events = require('./Handler/events')
const slash = require('./Handler/slash');


//  client.on('ready', () => {
//      checkGuilds();
//    });

client.on('ready', () => {
  sendMessage(client);
});

client.once('ready', () => {
  agendarRepostagem(client);
});

slash.run(client)
events.run(client)

client.slashCommands = new Collection();

client.login(config.token).catch((err) => {
    if(err?.message?.includes("intent")) return console.log(`${colors.red(`[LOG]`)} Ativa as Intents do Bot macaca`)
    if(err?.message?.includes("invalid")) return console.log(`${colors.red(`[LOG]`)} Coloca um token valido ou vc esqueceu de colocar o Token burro`);
  });

const messageLogChannelId = configuracao.get(`ConfigChannels.mensagens`);
const trafficLogChannelId = configuracao.get(`ConfigChannels.tráfego`);
const profileLogChannelId = configuracao.get(`ConfigChannels.tráfego`);

client.on('messageDelete', message => {
  if (messageLogChannelId) {
    handleDeletedMessage(message, messageLogChannelId, client)
  } else {
    return;
  }
});

client.on('messageUpdate', (oldMessage, newMessage) => {
  if (messageLogChannelId) {
    handleUpdatedMessage(oldMessage, newMessage, messageLogChannelId, client)
  } else {
    return;
  }
});

client.on('voiceStateUpdate', (oldState, newState) => {
  if (trafficLogChannelId) {
    handleVoiceStateUpdate(oldState, newState, trafficLogChannelId, client)
  } else {
    return;
  }
});

client.on('guildMemberUpdate', (oldMember, newMember) => {
  if (profileLogChannelId) {
    handleProfileUpdate(oldMember, newMember, profileLogChannelId, client)
  } else {
    return;
  }
});

const { EmbedBuilder } = require('discord.js');

client.on('guildMemberAdd', async (member) => {
  const cargoMembroId = configuracao.get(`ConfigRoles.cargomembro`);
  const canalBoasVindasId = configuracao.get(`ConfigChannels.entradas`) 
  try {
    const cargoMembro = await member.guild.roles.fetch(cargoMembroId);
    if (cargoMembro) await member.roles.add(cargoMembro);

    const canalBoasVindas = member.guild.channels.cache.get(canalBoasVindasId);
    if (canalBoasVindas) {
      const embed = new EmbedBuilder()
        .setColor('#4CAF50')
        .setTitle('Novo membro!')
        .setDescription(`Bem-vindo ${member} ao servidor!`)
        .setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
        .addFields({ name: 'Membro nº', value: member.guild.memberCount.toString() })
        .setTimestamp();

      await canalBoasVindas.send({ embeds: [embed] });
    }
  } catch (error) {
    console.error('Erro ao adicionar membro:', error);
  }
});

// Reset carrinho.json
const filePath = path.join(__dirname, './DataBaseJson', 'carrinhos.json');

function resetCarrinhos() {
    let data = {};

    fs.writeFile(filePath, JSON.stringify(data), 'utf8', (err) => {
        if (err) {
            console.log('Erro ao escrever no arquivo:', err);
        } else {
            console.log('[Reset carrinhos.json] Carrinhos zerados com sucesso!');
        }
    });
}

const job = schedule.scheduleJob({ hour: 5, minute: 57, tz: 'America/Sao_Paulo' }, function() {
  resetCarrinhos();
});
process.on('uncaughtException', (err) => {
  console.error('Erro não tratado:', err);
});

// Captura promessas rejeitadas não tratadas
process.on('unhandledRejection', (reason, promise) => {
  console.error('Rejeição não tratada na promise:', promise, 'Motivo:', reason);
});
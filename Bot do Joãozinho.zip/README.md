# Dz7 gostoso demais slk

- bom, quero q todos se fodam <3 
- pegando src Vazada qui noju <3
const { ActionRowBuilder, EmbedBuilder, StringSelectMenuBuilder } = require("discord.js");
require("dotenv/config");
const { configauth } = require("../DataBaseJson/index.js");

async function configEmbed({ interaction }) {
    const embed = new EmbedBuilder()
        .setColor(process.env.EMBED_COLOR)
        .setTitle(`${interaction.guild.name} | Configurar OAuth2`)
        .addFields(
            {
                name: "<:12726730942507950181:1302055449847398481>  Bloquear VPN",
                value: configauth.get(`${interaction.guild.id}.vpn`) 
                    ? "`🟢 Ativado`" 
                    : "`🔴 Desativado`",
                inline: true
            },
            {
                name: "<:12726733512019804261:1302055473608134726> Bloquear Proxy",
                value: configauth.get(`${interaction.guild.id}.proxy`) 
                    ? "`🟢 Ativado`" 
                    : "`🔴 Desativado`",
                inline: true
            },
            {
                name: "<:1272673520542941194:1302055461406900234> Bloquear Alt",
                value: configauth.get(`${interaction.guild.id}.alt`) 
                    ? "`🟢 Ativado`" 
                    : "`🔴 Desativado`",
                inline: true
            }
        );
    return embed;
}

async function configMenu() {
    const menu = new ActionRowBuilder()
        .addComponents(
            new StringSelectMenuBuilder()
                .setCustomId("config-auth")
                .setPlaceholder("Selecione uma opção")
                .addOptions(
                    { label: "Alt", value: "config_alt", description: "Bloquear/Desbloquear" },
                    { label: "VPN", value: "config_vpn", description: "Bloquear/Desbloquear" },
                    { label: "Proxy", value: "config_proxy",description: "Bloquear/Desbloquear" }
                )
        );
    return menu;
}

module.exports = { configEmbed, configMenu };
const { EmbedBuilder, ApplicationCommandType, ActionRowBuilder, ButtonBuilder, StringSelectMenuBuilder } = require("discord.js");
const { produtos, configuracao } = require("../DataBaseJson");
const { configauth } = require("../DataBaseJson/index.js");
const { usersauth } = require("../DataBaseJson/index.js");
const axios = require("axios");

require("dotenv/config");

async function embedew(interaction, client) {
    try {
      await axios.post(`${process.env.API_BASE}/register/server`, {
        proxy: false,
        vpn: false,
        alt: false
      });
    } catch (error) {
      console.error("Error posting to API:", error);
    }
  

  const embeddoecloudmuitozika = new EmbedBuilder()
    .setColor(`${configuracao.get(`Cores.Principal`) == null ? '0cd4cc': configuracao.get('Cores.Principal')}`)
    .setTitle(`Ecloud`)
    .setDescription(`A sincronização está ativada, garantindo que os dados do seu servidor (Canais, cargos, permissões, mensagens e configurações) sejam continuamente salvos na nuvem do seu eCloud Drive`)
    .addFields(
      { name: 'Membros 0Auth2', value: '0', inline: true },
      { name: 'Canal de logs', value: 'Não definido', inline: true },
      { name: 'Última sincronização na nuvem', value: 'Not found', inline: true },
      { name: "Bloquear VPN", value: `${configauth.get(`${interaction.guild.id}.vpn`) ? "`🟢 Ativado`" : "`🔴 Desativado`"}`, inline: true },
      { name: "Bloquear Proxy", value: `${configauth.get(`${interaction.guild.id}.proxy`) ? "`🟢 Ativado`" : "`🔴 Desativado`"}`, inline: true },
      { name: "Bloquear Alt", value: `${configauth.get(`${interaction.guild.id}.alt`) ? "`🟢 Ativado`" : "`🔴 Desativado`"}`, inline: true }
    )
    .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) })
    .setTimestamp();


async function original() {
    const row = new ActionRowBuilder()
    .addComponents(
      new StringSelectMenuBuilder()
      .setCustomId('config-auth')
      .setPlaceholder('Selecione qual desseja Bloquear')
      .addOptions(
        { label: "Mensagem de Verificação", value: "sendMessageVerify", description: "Envia a mensagem de verificação" },
        { label: "Cargo", value: "config_role", description: "Cargo de verificado após a verificação" },
      ),
    )
const row2 = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId("mensagemauth")
        .setLabel('Mensagem  0Auth2')
        .setStyle(1)
        .setDisabled(false),
      new ButtonBuilder()
        .setCustomId("canallogsecloud")
        .setLabel('Definir canal de logs')
        .setStyle(2)
        .setDisabled(false),
      new ButtonBuilder()
        .setCustomId("recuppanelks") //aqui
        .setLabel('Recuperar ')
        .setStyle(3)
        .setDisabled(false)
    )

const row3 = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId("vincularbotauth")
        .setLabel('Vincular Bot 0Auth2')
        .setStyle(2)
        .setDisabled(false),
      new ButtonBuilder()
        .setCustomId("actionsecloud")
        .setLabel('Psyche eCloud 0Auth2 Actions')
        .setStyle(2)
        .setDisabled(false)
    )
  const row4 = new ActionRowBuilder()
    .addComponents(
	  new ButtonBuilder()
        .setCustomId("auhtozationecloud")
        .setLabel('Resgatar eCloud Authorization')
        .setStyle(1)
        .setDisabled(false),
      new ButtonBuilder()
        .setLabel('Baixar eCloud Executor')
        .setStyle(5)
		.setURL(`https://discord.com/channels/1284061704472236042/1284061705042788386`)
        .setDisabled(false),
        new ButtonBuilder()
		.setCustomId(`voltar1`)
		.setLabel(`Voltar`)
		.setEmoji(`1238413255886639104`)
		.setStyle(2)
		.setDisabled(false)	
    )

    await interaction.update({ content: ``, components: [row, row2, row3, row4], embeds: [embeddoecloudmuitozika], ephemeral: true, files: []  })
}
return original;
}


module.exports = {
    embedew
}

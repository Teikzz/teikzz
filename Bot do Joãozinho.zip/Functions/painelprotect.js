const Mods = new JsonDatabase({ databasePath: "./DataBaseJson/moderacao.json" });

client.on('interactionCreate', async (interaction) => {
    if (interaction.isSelectMenu() && interaction.customId === 'selectMenuProtection') {
        if (interaction.values[0] === 'guarda') {
            const embed = new MessageEmbed()
                .setColor('#0099ff')
                .setTitle('Opções de Segurança')
                .setDescription('Escolha uma das opções de segurança abaixo.');

            const row = new MessageActionRow()
                .addComponents(
                    new MessageButton()
                        .setCustomId('guardRaid')
                        .setLabel('Ativar Guard Raid')
                        .setStyle('PRIMARY'),
                    new MessageButton()
                        .setCustomId('securityMassDelet')
                        .setLabel('Ativar Security Mass Delet')
                        .setStyle('PRIMARY'),
                        new ButtonBuilder()
                        .setLabel("Antilink (ON/OFF)")
                        .setEmoji(Mods.get("moderações.antilink") ? "1295604569933348864" : "1295604602456244228")
                        .setCustomId("antilinkonoff")
                        .setStyle(Mods.get("moderações.antilink") ? 3 : 4)
                );

            await interaction.update({ embeds: [embed], components: [row] });
        }
    }
});

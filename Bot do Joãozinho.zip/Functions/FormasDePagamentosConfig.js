const { ActionRowBuilder, TextInputBuilder, TextInputStyle, InteractionType, ModalBuilder, EmbedBuilder, ButtonBuilder } = require("discord.js");
const { configuracao } = require("../DataBaseJson");



async function FormasDePagamentos(interaction) {

    const embed = new EmbedBuilder()
    .setThumbnail(interaction.client.user.displayAvatarURL())
    .setAuthor({ name: `${interaction.client.user.username}`, iconURL: interaction.client.user.displayAvatarURL() })
    .setDescription(`## Formas de Pagamentos \n> Selecione o Botão que você deseja utilizar para começar a suas vendas! \n-# O nosso Sistema Mercado Pago esta em fase Beta, ainda iremos melhora-lo.`)
    .addFields(
        { name: `•  Mercado Pago`, value: `${configuracao.get("pagamentos.MpOnOff") != true ? `<:ligarb:1273787205252546581>\`Desabilitado\`` : `<:ligarb:1273787171995648050>\`Ativado\``}\n${configuracao.get("pagamentos.MpAPI") != "" ? `<:ligarb:1273787171995648050>\`Configurado\`` : `<:ligarb:1273787205252546581>\`Não configurado\``}`, inline: true },
        { name: `•  Pagamento Pix`, value: `${configuracao.get("pagamentos.SemiAutomatico.status") != true ? `<:ligarb:1273787205252546581>\`Desabilitado\`` : `<:ligarb:1273787171995648050>\`Ativado\``}\n${configuracao.get("pagamentos.SemiAutomatico.pix") != null ? `<:ligarb:1273787171995648050>\`Configurado\`` : `<:ligarb:1273787205252546581>\`Não configurado\``}`, inline: true },
    )
        .setColor(`${configuracao.get(`Cores.Principal`) == null ? '0cd4cc': configuracao.get('Cores.Principal')}`)
        .setFooter(
            { text: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) }
          )
          .setImage("https://media.discordapp.net/attachments/1295734703260831826/1305291547763413012/sistema_de_pagamento.png?ex=67327efc&is=67312d7c&hm=a367719e18ca7d84e888e1bbd0cb28000359e8b1e4f8a3898c8e5aeebffe4044&=&format=webp&quality=lossless&width=550&height=162")
          .setTimestamp()


    const row2 = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId("configurarmercadopago")
                .setLabel('Definir Mercado Pago')
                .setEmoji(`1265328482494447678`)
                .setDisabled(false)
                .setStyle(2),
                new ButtonBuilder()
                .setCustomId("ConfigurarPagamentoManual")
                .setLabel('Definir Pagamento Pix')
                .setEmoji(`1285023592987234326`)
                .setStyle(2),

        )

    const row4 = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId("voltaradawdwa")
                .setLabel('Voltar')
                .setEmoji(`1178068047202893869`)
                .setStyle(2)
    )


    await interaction.update({ content: ``, embeds: [embed], ephemeral: true, components: [row2, row4] })

}

module.exports = {
    FormasDePagamentos
}
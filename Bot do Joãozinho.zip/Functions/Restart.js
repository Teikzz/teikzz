const { ActivityType, ActionRowBuilder, EmbedBuilder, ButtonBuilder } = require('discord.js');
const { configuracao } = require('../DataBaseJson');

async function restart(client, status) {
    const systemLogsChannelId = configuracao.get('ConfigChannels.systemlogs');
    if (!systemLogsChannelId) {
        console.error('O ID do canal de logs do sistema não está definido!');
        return;
    }

    const embed = new EmbedBuilder()
        .setColor('#00FF00')
        .setAuthor({ name: `${client.user.username} | Reiniciado`, iconURL: "https://i.ibb.co/hZ0phK0/1256989934989082745.png" })
        .addFields(
            { name: `**Horario**`, value: `<t:${Math.ceil(Date.now() / 1000)}:R>`, inline: true },
            { name: `**Motivo**`, value: `\`\`Reinicio Automático\`\``, inline: false }
        )

    const row222 = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setURL('https://www.youtube.com/@eodz7appss')
                .setLabel('Reinicio Automatico')
                .setEmoji("1281664768595329105")
                .setStyle(5)
                .setDisabled(false)
        );

    try {
        const channel = await client.channels.fetch(systemLogsChannelId);
        if (!channel) {
            console.error(`O canal com ID ${systemLogsChannelId} não foi encontrado.`);
            return;
        }

        await channel.send({ components: [row222], embeds: [embed] });
        console.log(`Mensagem enviada no canal de logs: ${systemLogsChannelId}`);
    } catch (error) {
        console.error(`Erro ao enviar mensagem no canal de logs: ${systemLogsChannelId}`, error);
    }
}

module.exports = {
    restart
};

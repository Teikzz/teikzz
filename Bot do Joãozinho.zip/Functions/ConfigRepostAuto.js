const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const { produtos, configuracao, msgsauto } = require("../DataBaseJson");
const moment = require('moment-timezone');

async function AcoesRepostAutomatics(interaction, client) {
    const repostagemHora = configuracao.get(`Repostagem.Hora`) || "00:01";
    const currentStatus = configuracao.get(`Repostagem.Status`);

    // Obtendo a hora atual no fuso horário de São Paulo
    const currentTime = moment.tz("America/Sao_Paulo");
    
    const [hours, minutes] = repostagemHora.split(':').map(Number);
    let nextExecutionTime = moment.tz("America/Sao_Paulo").set({ hour: hours, minute: minutes, second: 0, millisecond: 0 });
    
    if (nextExecutionTime.isBefore(currentTime)) {
        nextExecutionTime.add(1, 'day');
    }
    
    const nextExecutionTimestamp = Math.floor(nextExecutionTime.valueOf() / 1000);
    const todosProdutos = await produtos.all();

    const embed = new EmbedBuilder()
    .setAuthor({ name: `${interaction.guild.name}`, iconURL: client.user.displayAvatarURL() }) // Nome do servidor e ícone do bot
    .setThumbnail(client.user.displayAvatarURL())
        .setColor(`${configuracao.get(`Cores.Principal`) == null ? '0cd4cc' : configuracao.get('Cores.Principal')}`)
        .setDescription(`## Repostagem Automática \n- Olá ${interaction.user}, segue abaixo as informações sobre o sistema de Repostagens de Produtos.`)
        .addFields(
            { name: `Quantidades de produtos em repostagens`, value: `\`${todosProdutos.length}\``, inline: true },
            { name: `Repostagem de Produtos`, value: currentStatus ? '`Ativado 🟢`' : '`Desativado 🔴`', inline: true },
            { name: `Próxima execução`, value: currentStatus ? `\`${nextExecutionTime.format('DD/MM/YYYY HH:mm:ss')}\`` : '`Desativado.`', inline: true },
            { name: `Tempo até a próxima execução`, value: currentStatus ? `<t:${nextExecutionTimestamp}:R>` : '`Desativado.`' },
        )
        .setFooter(
            { text: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) }
        )
        .setTimestamp();

    const row2 = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
            .setCustomId(currentStatus ? "desabilityRepost" : "enableRepost")
            .setLabel(currentStatus ? 'Desabilitar função' : 'Habilitar função')
            .setEmoji(`1259569896472182784`)
            .setStyle(currentStatus ? ButtonStyle.Danger : ButtonStyle.Success),
            new ButtonBuilder()
                .setCustomId("setTimeRepost")
                .setLabel('Definir horário')
                .setEmoji(`1241819612044197949`)
                .setStyle(2)
                .setDisabled(!currentStatus),
        )

    interaction.reply({ content: ``, components: [row2], embeds: [embed], ephemeral: true })
}

module.exports = {
    AcoesRepostAutomatics
}
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder } = require("discord.js");
const { configuracao } = require("../DataBaseJson")

async function semiConfigs(interaction, client) {

    const embed = new EmbedBuilder()
    .setThumbnail(interaction.client.user.displayAvatarURL())
    .setAuthor({ name: `${interaction.client.user.username}`, iconURL: interaction.client.user.displayAvatarURL() })
    .setColor(`${configuracao.get(`Cores.Principal`) == null ? '0cd4cc': configuracao.get('Cores.Principal')}`)
    .setDescription(`- Olá ${interaction.user}, segue abaixo as informações sobre o sistema de Pagamento Semi-Automáticos.`)
    .addFields(
        { name: `•  Pagamento Semi-Automático`, value: `${configuracao.get("pagamentos.SemiAutomatico.status") != true ? `<:ligarb:1273787205252546581>\`Desabilitado\`` : `<:ligarb:1273787171995648050>\`Ativado\``}\n${configuracao.get("pagamentos.SemiAutomatico.pix") != null ? `<:ligarb:1273787171995648050>\`Configurado\`` : `<:ligarb:1273787205252546581>\`Não configurado\``}`, inline: false },
    )
    .setImage("https://media.discordapp.net/attachments/1295734703260831826/1305292250619580436/sistema_pix.png?ex=67327fa3&is=67312e23&hm=dcb111fb56ca8cd7a6c32771d8db475d8be0ba4a6c64098b1fdd0e922fb14824&=&format=webp&quality=lossless&width=960&height=282")
    .setTimestamp()

    const row1 = new ActionRowBuilder()
    .addComponents(
        new ButtonBuilder().setCustomId(`onOffSemi`).setLabel(configuracao.get("pagamentos.SemiAutomatico.status") != false ? "Ativar/Desativar Pix" : "Ativar/Desativar Pix").setEmoji(`1285023592987234326`).setStyle(configuracao.get("pagamentos.SemiAutomatico.status") != false ? 2 : 2),
        new ButtonBuilder().setCustomId(`editConfigSemi`).setLabel(`Definir Pix`).setEmoji(`1246953149009367173`).setStyle(2),
    )

    const row2 = new ActionRowBuilder()
    .addComponents(
        new ButtonBuilder().setCustomId(`formasdepagamentos`).setLabel(`Voltar`).setEmoji(`1246953097033416805`).setStyle(2)
    )

    interaction.editReply({ content: ``, embeds: [embed], components: [row1, row2] })

}

module.exports = {
    semiConfigs
}
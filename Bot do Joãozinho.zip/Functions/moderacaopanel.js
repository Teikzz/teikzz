const { EmbedBuilder, ApplicationCommandType, ActionRowBuilder, ButtonBuilder } = require("discord.js");
const { configuracao } = require("../DataBaseJson");
const { JsonDatabase } = require("wio.db");

async function slamoderacaopainel(interaction, client) {
  // Indica ao Discord que a interação está sendo processada
  await interaction.deferUpdate();

  const embed = new EmbedBuilder()

  .setAuthor({ name: `${interaction.guild.name}`, iconURL: client.user.displayAvatarURL() }) // Nome do servidor e ícone do bot
  .setThumbnail(client.user.displayAvatarURL())
    .setColor(`${configuracao.get(`Cores.Principal`) == null ? '0cd4cc': configuracao.get('Cores.Principal')}`)
    .setDescription(`## Moderação \n> Aproveite os nossos recursos de sugestões e boas-vindas personalizadas, garantindo um ambiente seguro e organizado para o servidor.`)
    .setTimestamp();

  const row2 = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId("configsistemas")
        .setLabel('Sistema de Sugestão')
        .setEmoji(`1270447335851294794`)
        .setStyle(2)
        .setDisabled(false),
      new ButtonBuilder()
        .setCustomId("painelconfigbv") //aqui
        .setLabel('Boas Vindas')
        .setEmoji(`1238709839685746758`)
        .setStyle(2)
        .setDisabled(false)
    );

  const row3 = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId(`voltar2`)
        .setLabel(`Voltar`)
        .setEmoji(`1238413255886639104`)
        .setStyle(2)
        .setDisabled(false)
    );

  await interaction.editReply({ content: ``, components: [row2, row3], embeds: [embed], ephemeral: true });
}

module.exports = {
  slamoderacaopainel
};

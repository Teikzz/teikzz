const { ActionRowBuilder, EmbedBuilder, ButtonBuilder } = require('discord.js');
const { configuracao, estatisticas } = require('../DataBaseJson');
const axios = require('axios');
const { JsonDatabase } = require('wio.db');

async function Varredura(client) {
    const systemLogsChannelId = configuracao.get('ConfigChannels.systemlogs');
    if (!systemLogsChannelId) {
        console.log('Canal de systemlogs não está configurado.');
        return;
    }

    if (configuracao.get('pagamentos.MpAPI') == "") {
        console.log('A chave de API do Mercado Pago não está configurada.');
        return;
    }

    const embed3 = new EmbedBuilder()
        .setColor('#1844ff')
        .setAuthor({ name: ` — Varredura Anti-Fraude`, iconURL: "https://i.ibb.co/8sFgzVy/1238293159205797939.png" })
        .setDescription(`Seu Dream Bot está realizando uma varredura nos pagamentos para verificar a existência de quaisquer reembolsos suspeitos.`)
        .setFooter({ iconURL: "https://i.ibb.co/SBRZZjW/1238185861510594560.png", text: `Anti-Fraude - Dream Solutions.` })
        .setTimestamp();

    const row222 = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId('asSs')
                .setLabel('Notificação do Sistema')
                .setStyle(2)
                .setDisabled(true)
        );

    try {
        // Tenta buscar o canal configurado
        const channel = await client.channels.fetch(systemLogsChannelId);

        // Se o canal for encontrado, envia a mensagem de varredura
        await channel.send({ components: [row222], embeds: [embed3] });
    } catch (error) {
        console.log(`Erro ao tentar buscar o canal de systemlogs: ${error}`);
        return; // Sai da função se não conseguir buscar o canal
    }

    // Lógica para verificar reembolsos continua...
    const refundResponse = await axios.get('https://api.mercadopago.com/v1/payments/search', {
        params: {
            'access_token': `${configuracao.get('pagamentos.MpAPI')}`,
            'status': 'refunded'
        }
    });

    const dd = refundResponse.data.results;

    const refounds = new JsonDatabase({
        databasePath: "./DataBaseJson/refounds.json"
    });

    for (const element of dd) {
        const isRefunded = await refounds.get(`${element.id}`);

        if (!isRefunded) {
            await refounds.set(`${element.id}`, `Reembolsado`);

            let id = await element.external_reference;
            if (element.external_reference == null) {
                id = 'Não encontrado';
            }

            const embed = new EmbedBuilder()
                .setColor('#ff0000')
                .setAuthor({ name: ` — Reembolso Detectado`, iconURL: "https://i.ibb.co/x2W11bZ/1238293266034855958.png" })
                .setDescription(`Um reembolso foi detectado no sistema de pagamentos.`)
                .addFields(
                    { name: `**ID do pagamento**`, value: `\`${element.id}\``, inline: true },
                    { name: `**ID do usuário**`, value: `\`${id}\``, inline: true },
                    { name: `**Valor**`, value: `\`${element.transaction_amount}\``, inline: true },
                    { name: `**Data**`, value: `<t:${Math.ceil(Date.now() / 1000)}:R>`, inline: true },
                    { name: `**Status**`, value: `\`${element.status}\``, inline: true },
                    { name: `**Tipo de pagamento**`, value: `\`${element.payment_type_id}\``, inline: true },
                    { name: `**Tipo de operação**`, value: `\`${element.operation_type}\``, inline: true },
                );

            try {
                await channel.send({ components: [row222], embeds: [embed] });
            } catch (error) {
                console.error('Erro ao enviar a mensagem:', error);
            }

            const estatisticasData = estatisticas.fetchAll();
            for (const element2 of estatisticasData) {
                if (element2.data.idpagamento === element.id) {
                    estatisticas.delete(element2.ID);
                }
            }
        }
    }
}

module.exports = {
    Varredura
};

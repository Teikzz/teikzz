const { EmbedBuilder, ApplicationCommandType, ActionRowBuilder, ButtonBuilder } = require("discord.js");
const { configuracao } = require("../DataBaseJson");

async function Gerenciar(interaction, client) {

    // Criando o embed com título, descrição e cor
    const embed = new EmbedBuilder()
    .setAuthor({ name: `${interaction.guild.name}`, iconURL: client.user.displayAvatarURL() }) // Nome do servidor e ícone do bot
    .setThumbnail(client.user.displayAvatarURL())
    .setDescription('## Pagina Diversidades \n> Esse sistema otimiza a gestão de servidores de vendas no Discord, com configuração automatizada de cargos, moderação avançada, canais de logs, sistema anti-fake, personalização, múltiplas formas de pagamento e ferramentas exclusivas para vendedores. Ele oferece uma experiência organizada e segura para vendedores e clientes.')
    .setColor(`${configuracao.get(`Cores.Principal`) == null ? '0cd4cc' : configuracao.get('Cores.Principal')}`)
        .setTimestamp();

    // Primeira linha de botões
    const row1 = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId("configcargos")
                .setLabel('Definir Cargos')
                .setEmoji('1178086257784533092')
                .setStyle(2),

            new ButtonBuilder()
                .setCustomId("moderacaoslatestebot")
                .setLabel('Moderação')
                .setEmoji('1293077937343561768')
                .setStyle(2),

            new ButtonBuilder()
                .setCustomId("personalizarcanais")
                .setLabel('Definir Canais')
                .setEmoji('1178086457169170454')
                .setStyle(2),
                
                new ButtonBuilder()
                .setCustomId("personalizarantifake")
                .setLabel('Definir Anti-Fake')
                .setEmoji('1178086608004722689')
                .setStyle(2),
        );

    // Segunda linha de botões
    const row2 = new ActionRowBuilder()
        .addComponents(
            
            new ButtonBuilder()
                .setCustomId("formasdepagamentos")
                .setLabel('Definir Pagamentos')
                .setEmoji('1178086986360307732')
                .setStyle(1),

            new ButtonBuilder()
                .setCustomId("painelpersonalizar")
                .setLabel('Personalizar Bot')
                .setEmoji('1178066208835252266')
                .setStyle(2),


        );

    // Terceira linha de botões
    const row3 = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId("voltar1")
                .setLabel('Voltar')
                .setEmoji('1178068047202893869')
                .setStyle(2)
        );

    // Verifica se a interação é uma nova mensagem ou uma atualização
    if (interaction.message == undefined) {
        interaction.reply({ embeds: [embed], components: [row1, row2, row3], content: '' });
    } else {
        interaction.update({ embeds: [embed], components: [row1, row2, row3], content: '' });
    }
}

module.exports = {
    Gerenciar
};

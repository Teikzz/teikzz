const { EmbedBuilder, ApplicationCommandType, ActionRowBuilder, ButtonBuilder, ChannelType } = require("discord.js");
const { DentroCarrinho1 } = require("./DentroCarrinho");
const { carrinhos } = require("../DataBaseJson");

function VerificaçõesCarrinho(infos) {
    if (infos.estoque <= 0) return { error: 400, message: `Sem estoque disponível` };
    return { status: 202 };
}

async function CreateCarrinho(interaction, infos) {
    await interaction.reply({ content: '🔄️ Criando carrinho...', ephemeral: true }).then(async msg => {

        const thread2222 = interaction.channel.threads.cache.find(x => x.name === `🛒・${interaction.user.username}・${interaction.user.id}`);

        if (thread2222 !== undefined) {
            const row4 = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setURL(`https://discord.com/channels/${interaction.guild.id}/${thread2222.id}`)
                        .setLabel('Redirecionar')
                        .setStyle(5)
                );

            interaction.editReply({ content: `❌ | Você já possui um carrinho aberto.`, components: [row4] });
             return;
        }

        const thread = await interaction.channel.threads.create({
            name: `🛒・${interaction.user.username}・${interaction.user.id}`,
            autoArchiveDuration: 60,
            type: ChannelType.PrivateThread,
            reason: 'Needed a separate thread for moderation',
        });

        const row4 = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setURL(`https://discord.com/channels/${interaction.guild.id}/${thread.id}`)
                    .setLabel('Redirecionar')
                    .setStyle(5)
            );
        
        const embed = new EmbedBuilder()
            .setColor('#008a1e') 
            .setTitle('Carrinho Criado!')
            .setDescription(`Seu carrinho foi criado com sucesso, adicione os produtos que deseja comprar\n-# Para se redirecionar ao carrinho clique no botão abaixo..`);

        await msg.edit({ embeds: [embed], components: [row4], content: "" });

        await carrinhos.set(thread.id, { user: interaction.user, guild: interaction.guild, threadid: thread.id, infos: infos });

        DentroCarrinho1(thread);
    });
}

module.exports = {
    VerificaçõesCarrinho,
    CreateCarrinho
};
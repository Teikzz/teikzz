const { EmbedBuilder, ApplicationCommandType, ActionRowBuilder, ButtonBuilder } = require("discord.js");
const { produtos, configuracao } = require("../DataBaseJson");
const startTime = Date.now();
const maxMemory = 100;
const usedMemory = process.memoryUsage().heapUsed / 1024 / 1024;
const memoryUsagePercentage = (usedMemory / maxMemory) * 100;
const roundedPercentage = Math.min(100, Math.round(memoryUsagePercentage));

async function configqrcode(interaction, client) {

  const row2 = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId(`qrcode-button`)
        .setLabel(`Enviar logo`)
        .setEmoji(`1238299494181896306`)
        .setStyle(2),

      new ButtonBuilder()
        .setCustomId(`voltarsendlogo`)
        .setLabel(`Voltar`)
        .setEmoji(`1238413255886639104`)
        .setStyle(2)
    )

  if (interaction.message) {
    await interaction.update({ 
      content: `## Logo Marca \n> Aqui, você pode escolher o logo da sua marca, que será exibido nos QRCodes de pagamento criados.`, 
      components: [row2], 
      embeds: [], 
      ephemeral: true 
  });
  
  }
}

module.exports = {
  configqrcode
}

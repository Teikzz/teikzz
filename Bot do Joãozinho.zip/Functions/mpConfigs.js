const { ActionRowBuilder, TextInputBuilder, TextInputStyle, InteractionType, ModalBuilder, EmbedBuilder, ButtonBuilder } = require("discord.js");
const { configuracao } = require("../DataBaseJson");



async function mpConfigs(interaction) {

    const blockedBanksArray = configuracao.get(`pagamentos.BancosBloqueados`) || [];

        const BancosBloqueados = blockedBanksArray.map(bank => `${bank} `).join('\n')

    const embedx = new EmbedBuilder()
    .setThumbnail(interaction.client.user.displayAvatarURL())
    .setAuthor({ name: `${interaction.client.user.username}`, iconURL: interaction.client.user.displayAvatarURL() })
    .setColor(`${configuracao.get(`Cores.Principal`) == null ? '0cd4cc': configuracao.get('Cores.Principal')}`)
    .setDescription(`- Olá ${interaction.user}, segue abaixo as informações sobre o sistema de Pagamentos com seu Mercado Pago. \n-# Apos ativar o Mercado Pago, certifique-se que o forma de pagamento PIX nao esta habilitado.`)
    .setFields(
        { name: `•  Status`, value: `${configuracao.get("pagamentos.MpOnOff") != true ? `<:ligarb:1273787205252546581>\`Desabilitado\`` : `<:ligarb:1273787171995648050>\`Ativado\``}`, inline: false },
        { name: `•  Access Token`, value: `${configuracao.get(`pagamentos.MpAPI`) == "" ? `\`\`Seu Acess Token vai aparecer aqui!\`\`` : `\`\`\`${configuracao.get(`pagamentos.MpAPI`).slice(0, -33) + '***************************'}\`\`\``}`, inline: true  },
        { name: `•  Bank's Block `, value: `${blockedBanksArray.length <= 0 ? `\`\`Nenhum\`\`` : `\`\`${BancosBloqueados}\`\``}`, inline: true }
        )
        .setImage("https://media.discordapp.net/attachments/1295734703260831826/1305292250309464104/sistema_mercado_pago.png?ex=67327fa3&is=67312e23&hm=49cc31301e88d084e3fed11718b6717a360017acde63542c53b513783ade2ef7&=&format=webp&quality=lossless&width=960&height=282")
        .setColor(`${configuracao.get(`Cores.Principal`) == null ? '0cd4cc' : configuracao.get('Cores.Principal')}`)

    const fernandona = new ActionRowBuilder()
        .addComponents(

            new ButtonBuilder()
            .setCustomId("onOffMp")
            .setLabel(configuracao.get(`pagamentos.MpOnOff`) != false ? `Ativar/Desativar MP` : `Ativar/Desativar MP`)
            .setEmoji(`1265328482494447678`)
            .setStyle(configuracao.get(`pagamentos.MpOnOff`) != true ? 2 : 2)
            .setDisabled(false),

            new ButtonBuilder()
                .setCustomId("+18porra")
                .setLabel('Definir Access Token')
                .setEmoji(`1238417619657424929`)
                .setStyle(1)
                .setDisabled(false),

        )


    const fernandona2 = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId("bloquearbancos")
                .setLabel('Bloquear Banco')
                .setEmoji(`1238417761554927617`)
                .setStyle(2)
                .setDisabled(false),
            new ButtonBuilder()
                .setCustomId("exemplesbancks")
                .setLabel('Exemplos Bancos')
                .setEmoji(`1238417688129310782`)
                .setStyle(2)
                .setDisabled(false)
        )

    const fernandona3 = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId("formasdepagamentos")
                .setLabel('Voltar')
                .setEmoji(`1238413255886639104`)
                .setStyle(2)
                .setDisabled(false),

        )

    interaction.update({ embeds: [embedx], components: [fernandona, fernandona2, fernandona3], content: `` })

}

module.exports = {
    mpConfigs
}
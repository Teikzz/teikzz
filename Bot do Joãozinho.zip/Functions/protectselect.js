const { MessageActionRow, MessageButton, MessageSelectMenu, MessageEmbed } = require('discord.js');

// Botão inicial que vai abrir o Select Menu
client.on('interactionCreate', async (interaction) => {
    if (interaction.isButton() && interaction.customId === 'protecaoserver') {
        const row = new MessageActionRow()
            .addComponents(
                new MessageSelectMenu()
                    .setCustomId('selectMenuProtection')
                    .setPlaceholder('Escolha uma opção')
                    .addOptions([
                        {
                            label: 'Guarda',
                            description: 'Opções de segurança do servidor',
                            value: 'guarda',
                        },
                    ]),
            );

        await interaction.update({ content: 'Escolha uma opção:', components: [row] });
    }
});

const { EmbedBuilder, ApplicationCommandType, ActionRowBuilder, ButtonBuilder } = require("discord.js");
const { createCanvas, loadImage, registerFont } = require('canvas');
const { produtos, configuracao } = require("../DataBaseJson");
const { tr } = require("faker/lib/locales");
const startTime = Date.now();
const maxMemory = 100;
const usedMemory = process.memoryUsage().heapUsed / 1024 / 1024;
const memoryUsagePercentage = (usedMemory / maxMemory) * 100;
const roundedPercentage = Math.min(100, Math.round(memoryUsagePercentage));

function getSaudacao() {
  const brazilTime = new Date().toLocaleString("en-US", { timeZone: "America/Sao_Paulo" });
  const hora = new Date(brazilTime).getHours();
  return 'Olá';
}

async function Painel(interaction, client) {
  if (!interaction) {
    console.error("Erro: 'interaction' não foi passado para a função.");
    return;
  }

  const embed = new EmbedBuilder()
    .setThumbnail(client.user.displayAvatarURL())
    .setColor(`${configuracao.get(`Cores.Principal`) == null ? '696b6b' : configuracao.get('Cores.Principal')}`)
    .setAuthor({ name: `${interaction.guild.name} - Página Inicial.`, iconURL: client.user.displayAvatarURL() })
    .setImage("https://media.discordapp.net/attachments/1295734703260831826/1305190682759135368/Painel_de_control.png?ex=6732210c&is=6730cf8c&hm=279e109eca8da58780ee9d9d08ac62320ac2ed90f1b3dfb93236a2227c1e8aaf&=&format=webp&quality=lossless&width=550&height=162")
    .setDescription(`- ${getSaudacao()} ${interaction.user}, veja abaixo as seguintes **informações** do que voce poderá configurar. \n-# Sistema de eCloud esta desativado pois estamos construindo ainda!`)
    .addFields(
      {
        name: `**Versão do Bot:**`,
        value: `\`\`\`1.0.0\`\`\``, // Adicione o valor correto da versão
        inline: true
      },
      {
        name: `**Gerenciando:**`,
        value: `\`\`\`${interaction.client.user.username}\`\`\``,
        inline: true
      },
    )


  const row2 = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder().setCustomId("painelconfigvendas").setLabel('Sistema de Loja').setEmoji('1303553815890493513').setStyle(1),
      new ButtonBuilder().setCustomId("ecloudpanel").setLabel('Sistema de eCloud').setDisabled(true).setEmoji('1238298541374439505').setStyle(1),
      new ButtonBuilder().setCustomId("painelconfigticket").setLabel('Sistema de Ticket').setEmoji('1236447625675407463').setStyle(1),
    );

  const row3 = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder().setCustomId("protecaoserver").setLabel('Proteção').setEmoji('1303850342072713329').setStyle(2),
      new ButtonBuilder().setCustomId("actionsautomations").setLabel('Ações Automáticas').setEmoji('1292614702899396659').setStyle(2),
      new ButtonBuilder().setCustomId("gerenciarconfigs").setLabel('Definições').setEmoji('1178066377014255828').setStyle(2),
    );

  // Responder ou atualizar interação, conforme a condição
  await interaction.editReply({ content: '', files: [], components: [row2, row3], embeds: [embed], ephemeral: true });
}


async function Gerenciar2(interaction, client) {

  const ggg = produtos.valueArray();

  const embed = new EmbedBuilder()
    .setColor(`${configuracao.get(`Cores.Principal`) == null ? '0cd4cc' : configuracao.get('Cores.Principal')}`)
    .setAuthor({ name: `${interaction.guild.name}`, iconURL: client.user.displayAvatarURL() }) // Nome do servidor e ícone do bot
    .setThumbnail(client.user.displayAvatarURL())
    .setImage("https://media.discordapp.net/attachments/1295734703260831826/1305190128523673680/Sistema_de_vendas.png?ex=67322087&is=6730cf07&hm=5c00faf13248e630efa79f75b335a7c5218545b0686a70483811bc0688dd1d97&=&format=webp&quality=lossless&width=960&height=282")
    .setDescription(`- ${getSaudacao()} ${interaction.user}, veja abaixo as seguintes **informações** do que voce poderá utilizar.`)
    .addFields(
      {
        name: `**Produtos Criados:**`,
        value: `\`\`\`${ggg.length}\`\`\``,
        inline: true
      }
    )


  const row2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('criarrrr').setLabel('Criar').setEmoji('1305179987820937317').setStyle(3),
    new ButtonBuilder().setCustomId('gerenciarotemae').setLabel('Gerenciar').setEmoji('1305180954238914650').setStyle(1),
    new ButtonBuilder().setCustomId('gerenciarposicao').setLabel('Posições').setDisabled(true).setEmoji('1178086608004722689').setStyle(2),
    new ButtonBuilder().setCustomId('marca-qrcode').setLabel('Qr Code').setEmoji('1297329746526343229').setStyle(2),
  );

  const row3 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('voltar00').setLabel('Voltar').setEmoji('1178068047202893869').setStyle(2)
  );

  await interaction.editReply({ files: [], components: [row2, row3], embeds: [embed], content: '' });
}

module.exports = {
  Painel,
  Gerenciar2
};

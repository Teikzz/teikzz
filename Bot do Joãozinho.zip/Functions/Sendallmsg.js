const { MsgVendas } = require("../DataBaseJson/")


async function ReSendAllMsg(client) {

    const produtossalvos = MsgVendas.fetchAll()

    for (const produto in produtossalvos) {
        let produtoid = produtossalvos[produto]
        let canalvendas = await client.channels.cache.get(produtoid.data.mensagem.canal)
        if (!canalvendas) return
        let mensageminfo 
        try {
            mensageminfo = await canalvendas.messages.fetch(produtoid.data.mensagem.mensagem)
        } catch (error) { }
        if (!mensageminfo) return
        try {
            await mensageminfo.delete()
        } catch (error) { }
        canalvendas.send({ content: mensageminfo.content, components: mensageminfo.components }).then(async (msg) => {
            MsgVendas.set(`${produtoid.ID}.mensagem.mensagem`, msg.id)
            MsgVendas.set(`${produtoid.ID}.mensagem.canal`, msg.channel.id)
        })
    }
    

}

module.exports = {
    ReSendAllMsg
}
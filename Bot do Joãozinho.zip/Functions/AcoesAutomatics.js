const { EmbedBuilder, ApplicationCommandType, ActionRowBuilder, ButtonBuilder } = require("discord.js");
const { produtos, configuracao } = require("../DataBaseJson");

async function AcoesAutomaticsConfigs(interaction, client) {

  const embed = new EmbedBuilder()
  .setAuthor({ name: `${interaction.guild.name}`, iconURL: client.user.displayAvatarURL() }) // Nome do servidor e ícone do bot
  .setThumbnail(client.user.displayAvatarURL())
    .setColor(`${configuracao.get(`Cores.Principal`) == null ? '0cd4cc': configuracao.get('Cores.Principal')}`)
    .setDescription(`## Automatização \n> Aqui você pode configurar algumas ações automáticas para manter a segurança e a ordem no seu servidor.`)
    .setFooter(
      { text: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) }
    )
    .setTimestamp()

  const row2 = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId("configlock")
        .setLabel('Definir Lock-Channels')
        .setEmoji(`1304514418025037925`)
        .setStyle(2)
        .setDisabled(false),
      new ButtonBuilder()
        .setCustomId("automaticRepostar")
        .setLabel('Definir Repostagem')
        .setEmoji(`1238303687248576544`)
        .setStyle(2)
        .setDisabled(false),
    )

      const row3 = new ActionRowBuilder()
        .addComponents(
      new ButtonBuilder()
        .setCustomId("MsgsAutoConfig") //aqui
        .setLabel('Definir Mensagens')
        .setEmoji(`1238709839685746758`)
        .setStyle(2)
        .setDisabled(false),
        new ButtonBuilder()
        .setCustomId("configClean")
        .setLabel('Definir Limpeza')
        .setEmoji(`1238300628225228961`)
        .setStyle(2)
        .setDisabled(false),
    )

  const row4 = new ActionRowBuilder()
    .addComponents(
        new ButtonBuilder().setCustomId(`voltar1`).setLabel(`Voltar`).setEmoji(`1238413255886639104`).setStyle(2).setDisabled(false)
    )

    await interaction.update({ content: ``, components: [row2, row3, row4], embeds: [embed], ephemeral: true, files: []  })
  }




module.exports = {
  AcoesAutomaticsConfigs
}

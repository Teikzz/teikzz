const { EmbedBuilder } = require('discord.js');

function handleProfileUpdate(oldMember, newMember, logChannelId, client) {
    client.channels.fetch(logChannelId).then(logChannel => {
        if (!logChannel) return;

        if (oldMember.nickname !== newMember.nickname) {
            const embed = new EmbedBuilder()
                .setColor(0x3498DB) 
                .setTitle('📛 Mudança de Nickname')
                .setDescription(`${newMember.user.tag} alterou seu nickname`)
                .addFields(
                    { name: 'Antigo', value: oldMember.nickname || 'Nenhum', inline: true },
                    { name: 'Novo', value: newMember.nickname || 'Nenhum', inline: true }
                )
                .setTimestamp();

            logChannel.send({ embeds: [embed] });
        }

        if (oldMember.user.avatarURL() !== newMember.user.avatarURL()) {
            const embed = new EmbedBuilder()
                .setColor(0x1ABC9C) 
                .setTitle('🖼️ Mudança de Avatar')
                .setDescription(`${newMember.user.tag} atualizou seu avatar`)
                .setThumbnail(newMember.user.avatarURL())
                .addFields(
                    { name: 'Info', value: 'Avatar atualizado para o mostrado à direita.', inline: false }
                )
                .setTimestamp();

            logChannel.send({ embeds: [embed] });
        }
    });
}

module.exports = { handleProfileUpdate };

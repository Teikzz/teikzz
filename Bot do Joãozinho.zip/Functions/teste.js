const { configEmbed, configMenu } = require("../components/configAuth.js");
const { usersauth } = require("../DataBaseJson/index.js");
const axios = require('axios');
require('dotenv').config();

async function configurarOauth2testedesgraca(interaction) {
  try {
    await interaction.reply({ 
      embeds: [await configEmbed({ interaction: interaction })], 
      components: [await configMenu()], 
      ephemeral: true 
    });

    if (!usersauth.get(`${interaction.user.id}.guild`)) {
      usersauth.set(`${interaction.user.id}.guild`, interaction.guild.id);
      await axios.post(`${process.env.API_BASE}/register/server`, {
        data: {
          id: interaction.guild.id,
          name: interaction.guild.name,
          iconURL: interaction.guild.iconURL(),
          proxy: false,
          vpn: false,
          alt: false
        }
      });
    }
  } catch (error) {
    console.error(error);
    await interaction.reply({ content: 'Ocorreu um erro ao processar o comando.', ephemeral: true });
  }
}

module.exports = { configurarOauth2testedesgraca };
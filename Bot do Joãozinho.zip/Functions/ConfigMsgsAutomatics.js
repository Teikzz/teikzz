const { EmbedBuilder, ApplicationCommandType, ActionRowBuilder, ButtonBuilder } = require("discord.js");
const { produtos, configuracao } = require("../DataBaseJson");
const { msgsauto } = require("../DataBaseJson");

async function AcoesMsgsAutomatics(interaction, client) {

    const intervalMinutes = msgsauto.get('intervalMinutes') || 3; // Valor padrão de 3 minutos se não definido
    const interval = intervalMinutes * 60 * 1000; // Converte milissegundos em minutos

    const channels = msgsauto.get("channels") || []; // Garante que channels seja um array vazio se não definido

    const embed = new EmbedBuilder()
    .setAuthor({ name: `${interaction.guild.name}`, iconURL: client.user.displayAvatarURL() }) // Nome do servidor e ícone do bot
    .setThumbnail(client.user.displayAvatarURL())
        .setColor(`${configuracao.get(`Cores.Principal`) == null ? '0cd4cc' : configuracao.get('Cores.Principal')}`)
        .setDescription(`## 💬 Mensagens automáticas \n> O sistema de repostagem de mensagens permite que você defina mensagens personalizadas, inclua imagens e escolha os canais de envio. É possível configurar intervalos de repostagem, especificando quantos minutos ou horas entre cada envio. Essa automação garante que informações importantes sejam compartilhadas regularmente, mantendo os membros do canal sempre atualizados de forma eficaz.`)
        .addFields(
            {
                name: `Tempo para apagar mensagens`, value: `\`${intervalMinutes} minuto(s)\``
            }
        )
        .setFooter(
            { text: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) }
        )
        .setTimestamp();

    const row2 = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId("automaticMessages")
                .setLabel('Criar mensagem')
                .setEmoji(`1246953350067388487`)
                .setStyle(2)
                .setDisabled(false),
            new ButtonBuilder()
                .setCustomId("removeAutomaticMessages")
                .setLabel('Ver/Excluir Mensagens')
                .setEmoji(`1246953268211613747`)
                .setStyle(2)
                .setDisabled(channels.length <= 0), // Agora garantido que channels existe
            new ButtonBuilder()
                .setCustomId("timeUploadMessage")
                .setLabel('Tempo de repostagem')
                .setEmoji(`1246953228655132772`)
                .setStyle(2)
                .setDisabled(false)
        );

    interaction.reply({ content: ``, components: [row2], embeds: [embed], ephemeral: true });
}

module.exports = {
    AcoesMsgsAutomatics
};

const { EmbedBuilder, ApplicationCommandType, ActionRowBuilder, ButtonBuilder, StringSelectMenuBuilder } = require("discord.js");
const { configuracao } = require("../DataBaseJson");


async function ConfigChannels(interaction, client) {

    const row1 = new ActionRowBuilder()
        .addComponents(
            new StringSelectMenuBuilder()
                .setCustomId(`selectChannelC`)
                .addOptions(
                    {
                        value: `logpedidos`,
                        label: `Definir canal de logs de pedidos`,
                        emoji: `1246953187529855037`
                    },
                    {
                        value: `eventbuy`,
                        label: `Definir canal de evento de compras`,
                        emoji: `1246953442283618334`
                    },
                    {
                        value: `boasvindascoole`,
                        label: `Definir canal de boas vindas`,
                        emoji: `1246955057879187508`
                    },
                    {
                        value: `systemlogs`,
                        label: `Definir canal de logs do sistema`,
                        emoji: `1246954960218886146`
                    },
                    {
                        value: `logentrada`,
                        label: `Definir canal de logs de entradas`,
                        emoji: `1246955020050759740`
                    },
                    {
                        value: `logsaida`,
                        label: `Definir canal de logs de saídas`,
                        emoji: `1246955006242983936`
                    },
                    {
                        value: `logmensagem`,
                        label: `Definir canal de logs de mensagens`,
                        emoji: `1246953149009367173`
                    },
                    {
                        value: `trafegocall`,
                        label: `Definir canal de logs de tráfego de call`,
                        emoji: `1246954972155875328`
                    },
                    {
                        value: `feedback`,
                        label: `Definir canal de logs de feedback`,
                        emoji: `1246955036433453259`
                    }
                )
                .setPlaceholder(`Clique aqui para redefinir algum canal`)
                .setMaxValues(1)
        )
    const row2 = new ActionRowBuilder()
        .addComponents(

            new ButtonBuilder()
                .setCustomId("voltar2")
                .setLabel('Voltar')
                .setEmoji(`1178068047202893869`)
                .setStyle(2),
            new ButtonBuilder()
                .setCustomId("criandooscanaissempa")
                .setLabel('Criar canais')
                .setEmoji('1294487262532206613')
                .setStyle(2)
        )



    const embed = new EmbedBuilder()

        .setAuthor({ name: `${interaction.guild.name}`, iconURL: client.user.displayAvatarURL() }) // Nome do servidor e ícone do bot
        .setThumbnail(client.user.displayAvatarURL())
        .setColor(`${configuracao.get(`Cores.Principal`) == null ? '0cd4cc' : configuracao.get('Cores.Principal')}`) //0cd4cc
        .setDescription(` ## Configurar Canais \n
- **Canal de log de pedidos:** ${configuracao.get(`ConfigChannels.logpedidos`) == null ? `Não definido` : `<#${configuracao.get(`ConfigChannels.logpedidos`)}>`}
- **Canal de evento de compras:** ${configuracao.get(`ConfigChannels.eventbuy`) == null ? `Não definido` : `<#${configuracao.get(`ConfigChannels.eventbuy`)}>`}
- **Canal de boas vindas:** ${configuracao.get(`ConfigChannels.boasvindascoole`) == null ? `Não definido` : `<#${configuracao.get(`ConfigChannels.boasvindascoole`)}>`}
- **Canal de logs do sistema:** ${configuracao.get(`ConfigChannels.systemlogs`) == null ? `Não definido` : `<#${configuracao.get(`ConfigChannels.systemlogs`)}>`}
- **Canal de logs de entradas:** ${configuracao.get(`ConfigChannels.entradas`) == null ? `Não definido` : `<#${configuracao.get(`ConfigChannels.entradas`)}>`}
- **Canal de logs de saídas:** ${configuracao.get(`ConfigChannels.saídas`) == null ? `Não definido` : `<#${configuracao.get(`ConfigChannels.saídas`)}>`}
- **Canal de logs de mensagens:** ${configuracao.get(`ConfigChannels.mensagens`) == null ? `Não definido` : `<#${configuracao.get(`ConfigChannels.mensagens`)}>`}
- **Canal de logs de tráfego em call:** ${configuracao.get(`ConfigChannels.tráfego`) == null ? `Não definido` : `<#${configuracao.get(`ConfigChannels.tráfego`)}>`}
- **Canal de feedback:** ${configuracao.get(`ConfigChannels.feedback`) == null ? `Não definido` : `<#${configuracao.get(`ConfigChannels.feedback`)}>`}
`)
        .setFooter(
            { text: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) }
        )
        .setTimestamp()

    interaction.update({ content: ``, embeds: [embed], components: [row1, row2] })

}


async function ConfigRoles(interaction, client) {

    const row1 = new ActionRowBuilder()
        .addComponents(
            new StringSelectMenuBuilder()
                .setCustomId(`selectCargoC`)
                .addOptions(
                    {
                        value: `definircargoadm`,
                        label: `Definir cargo de Administrador`,
                        emoji: `1246954960218886146`
                    },
                    {
                        value: `definircargosup`,
                        label: `Definir cargo de Suporte`,
                        emoji: `1246955036433453259`
                    },
                    {
                        value: `roleclienteease`,
                        label: `Definir cargo de Cliente`,
                        emoji: `1256806658101870684`
                    },
                    {
                        value: `rolememberok`,
                        label: `Definir cargo de Membro`,
                        emoji: `1246955106944028774`
                    }
                )
                .setPlaceholder(`Clique aqui para definir algum cargo`)
                .setMaxValues(1)
        )

    const row2 = new ActionRowBuilder()
        .addComponents(

            new ButtonBuilder()
                .setCustomId("voltar2")
                .setLabel('Voltar')
                .setEmoji(`1178068047202893869`)
                .setStyle(2)
        )


    const embed = new EmbedBuilder()

        .setColor(`${configuracao.get(`Cores.Principal`) == null ? '0cd4cc' : configuracao.get('Cores.Principal')}`)
        .setAuthor({ name: `${interaction.guild.name}`, iconURL: client.user.displayAvatarURL() }) // Nome do servidor e ícone do bot
        .setThumbnail(client.user.displayAvatarURL())
        .setDescription(`## Configurar cargos \n
- **Cargo de Administrador:** ${configuracao.get(`ConfigRoles.cargoadm`) == null ? `Não definido` : `<@&${configuracao.get(`ConfigRoles.cargoadm`)}>`}
- **Cargo de Suporte:** ${configuracao.get(`ConfigRoles.cargosup`) == null ? `Não definido` : `<@&${configuracao.get(`ConfigRoles.cargosup`)}>`}
- **Cargo de Cliente:** ${configuracao.get(`ConfigRoles.cargoCliente`) == null ? `Não definido` : `<@&${configuracao.get(`ConfigRoles.cargoCliente`)}>`}
- **Cargo de Membro:** ${configuracao.get(`ConfigRoles.cargomembro`) == null ? `Não definido` : `<@&${configuracao.get(`ConfigRoles.cargomembro`)}>`}

    `)
        .setTimestamp()

    interaction.update({ content: ``, embeds: [embed], components: [row1, row2] })

}


module.exports = {
    ConfigRoles,
    ConfigChannels
}

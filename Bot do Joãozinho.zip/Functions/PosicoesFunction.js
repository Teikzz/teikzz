const { createCanvas, loadImage } = require('canvas');
const { AttachmentBuilder, ActionRowBuilder, ButtonBuilder } = require("discord.js");
const { configuracao } = require("../DataBaseJson");
const { EstatisticasKing } = require("../index.js");

async function Posicao1(interaction, client) {
    const aa = configuracao.get(`posicoes`);
    const pos1 = aa?.pos1;
    const pos2 = aa?.pos2;
    const pos3 = aa?.pos3;

    const canvas = createCanvas(600, 300); // Ajuste de tamanho do canvas
    const ctx = canvas.getContext('2d');

    // Simulando o fundo de uma embed com cor sólida
    ctx.fillStyle = '#2F3136'; // Cor de fundo da embed
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Bordas arredondadas (se precisar de efeito de borda)
    ctx.strokeStyle = '#202225'; // Cor da borda
    ctx.lineWidth = 5;
    ctx.strokeRect(0, 0, canvas.width, canvas.height);

    // Definir estilo do texto da embed
    ctx.font = '14px Arial';
    ctx.fillStyle = '#ffffff'; // Cor do texto da embed
    ctx.textAlign = 'left';

    // Título centralizado
    ctx.font = 'bold 20px Arial';
    ctx.fillText("Posições", canvas.width / 2 - ctx.measureText("Posições").width / 2, 40);

    // Descrição da embed
    ctx.font = '14px Arial';
    const descricao = 'As "posições" são cargos personalizáveis que você pode definir para que os clientes recebam quando gastam uma certa quantia no servidor.';
    wrapText(ctx, descricao, 20, 70, canvas.width - 40, 18);

    // Primeira Colocação
    const pos1Text = pos1 == undefined ? `Não configurado` : `Recebe o cargo <@&${pos1.role}> após gastar R$ ${Number(pos1.valor).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}.`;
    ctx.font = 'bold 16px Arial';
    ctx.fillText("Primeira Colocação:", 20, 140);
    ctx.font = '14px Arial';
    wrapText(ctx, pos1Text, 20, 160, canvas.width - 40, 18);

    // Segunda Colocação
    const pos2Text = pos2 == undefined ? `Não configurado` : `Recebe o cargo <@&${pos2.role}> após gastar R$ ${Number(pos2.valor).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}.`;
    ctx.font = 'bold 16px Arial';
    ctx.fillText("Segunda Colocação:", 20, 200);
    ctx.font = '14px Arial';
    wrapText(ctx, pos2Text, 20, 220, canvas.width - 40, 18);

    // Terceira Colocação
    const pos3Text = pos3 == undefined ? `Não configurado` : `Recebe o cargo <@&${pos3.role}> após gastar R$ ${Number(pos3.valor).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}.`;
    ctx.font = 'bold 16px Arial';
    ctx.fillText("Terceira Colocação:", 20, 260);
    ctx.font = '14px Arial';
    wrapText(ctx, pos3Text, 20, 280, canvas.width - 40, 18);

    // Converte o canvas em uma imagem
    const attachment = new AttachmentBuilder(canvas.toBuffer(), { name: 'posicoes.png' });

    // Botões
    const row4 = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder().setCustomId("Editarprimeiraposição").setLabel('Editar primeira posição').setEmoji(`1192563018547081369`).setStyle(1),
            new ButtonBuilder().setCustomId("Editarsegundaposição").setLabel('Editar segunda posição').setEmoji(`1192563056522309672`).setStyle(1),
            new ButtonBuilder().setCustomId("Editarterceiraposição").setLabel('Editar terceira posição').setEmoji(`1192563090726846464`).setStyle(1)
        );

    const row5 = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder().setCustomId("voltar3").setLabel('Voltar').setEmoji(`1178068047202893869`).setStyle(2)
        );

    // Atualiza a interação com a imagem e os botões
    await interaction.update({ files: [attachment], components: [row4, row5] });
}

// Função auxiliar para quebra de linha do texto
function wrapText(ctx, text, x, y, maxWidth, lineHeight) {
    const words = text.split(' ');
    let line = '';
    for (let n = 0; n < words.length; n++) {
        const testLine = line + words[n] + ' ';
        const metrics = ctx.measureText(testLine);
        const testWidth = metrics.width;
        if (testWidth > maxWidth && n > 0) {
            ctx.fillText(line, x, y);
            line = words[n] + ' ';
            y += lineHeight;
        } else {
            line = testLine;
        }
    }
    ctx.fillText(line, x, y);
}

async function CheckPosition(client) {
    const aa = configuracao.get(`posicoes`);
    if (aa === null) return;
    const { pos1, pos2, pos3 } = aa ?? {};
    await Promise.all(client.guilds.cache.map(async (guild) => {
        await processPosition(pos1, guild);
        await processPosition(pos2, guild);
        await processPosition(pos3, guild);
    }));
    async function processPosition(pos, guild) {
        if (!pos) return;

        const role = guild.roles.cache.get(pos.role);
        const aa = await EstatisticasKing.GastouMais(null, Number(pos.valor));
        try {
            const members = await guild.members.fetch({ user: aa.map(user => user.userid) });

            for (const user of aa) {
                const member = members.get(user.userid);
                if (member && !member.roles.cache.has(role.id)) {
                    await member.roles.add(role.id).catch(() => { });
                }
            }
        } catch (error) { }
    }
}

module.exports = { Posicao1, CheckPosition };

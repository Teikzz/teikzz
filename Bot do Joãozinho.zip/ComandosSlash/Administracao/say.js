const {
    EmbedBuilder, PermissionFlagsBits, ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType,
    ModalBuilder, TextInputBuilder, TextInputStyle, ApplicationCommandOptionType
} = require("discord.js");
const { JsonDatabase } = require("wio.db");

const emj = new JsonDatabase({ databasePath: "./DataBaseJson/emojis.json" });
const dbp = new JsonDatabase({ databasePath: "./DataBaseJson/perms.json" });
const dbc = new JsonDatabase({ databasePath: "./DataBaseJson/botconfig.json" });

module.exports = {
    name: 'say',
    description: "Envie uma mensagem normal personalizada",
    options: [{
        name: 'channel',
        description: 'Qual canal será enviado?',
        type: ApplicationCommandOptionType.Channel,
        required: true
    }],
    run: async (client, interaction) => {
        // Verifica se o usuário tem permissão para usar o comando
        const userPermission = dbp.get(`${interaction.user.id}`);
        if (interaction.user.id !== userPermission) {
            return interaction.reply({ ephemeral: true, content: `${emj.get('13')} | Você não tem permissão para usar este comando!` });
        }

        // Obtém o canal da interação e valida
        const channel = interaction.options.getChannel('channel');
        if (!channel || !channel.isTextBased()) {
            return interaction.reply({ ephemeral: true, content: `${emj.get('13')} | Canal inválido ou não permitido para enviar mensagens!` });
        }

        let mensagem, imagem;
        let buttons = []; // Definindo buttons dentro do escopo da função

        const embedConfig = new EmbedBuilder()
            .setTitle("Configure abaixo os campos da mensagem que deseja configurar.")
            .setFooter({ text: "Clique em cancelar para cancelar o anúncio." })
            .setColor(dbc.get('color'));

        const rowActions = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder().setStyle(ButtonStyle.Secondary).setCustomId('configmsg').setLabel('Alterar Mensagem'),
                new ButtonBuilder().setStyle(ButtonStyle.Secondary).setCustomId('configimg').setLabel('Alterar Imagem'),
                new ButtonBuilder().setStyle(ButtonStyle.Secondary).setCustomId('configbuttons').setLabel('Configurar Botões')
            );

        const rowConfirm = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder().setCustomId('cancelar').setLabel('Cancelar').setStyle(ButtonStyle.Danger),
                new ButtonBuilder().setCustomId('send').setLabel('Enviar').setStyle(ButtonStyle.Success),
                new ButtonBuilder().setCustomId('preview').setLabel('Preview').setStyle(ButtonStyle.Primary)
            );

        const msg = await interaction.reply({ embeds: [embedConfig], components: [rowActions, rowConfirm] });

        const collector = msg.createMessageComponentCollector({ componentType: ComponentType.Button, time: 360_000 });

        collector.on('collect', async i => {
            if (i.user.id !== interaction.user.id) return;

            // Cancela a operação
            if (i.customId === 'cancelar') {
                await i.deferUpdate();
                return i.deleteReply();
            }

            // Preview da mensagem
            if (i.customId === 'preview') {
                const rowPreview = new ActionRowBuilder();
                buttons.forEach(({ nome, link, emoji }) => {
                    const button = new ButtonBuilder()
                        .setStyle(ButtonStyle.Link)
                        .setLabel(nome)
                        .setURL(link);

                    if (emoji) button.setEmoji(emoji);
                    rowPreview.addComponents(button);
                });

                await i.reply({
                    content: mensagem,
                    components: rowPreview.components.length > 0 ? [rowPreview] : [],
                    files: imagem ? [imagem] : [],
                    ephemeral: true
                }).catch(() => i.reply({ content: `${emj.get('13')} | Houve um erro ao processar o anúncio`, ephemeral: true }));
                return;
            }

            // Envia a mensagem
            if (i.customId === 'send') {
                const rowSend = new ActionRowBuilder();
                buttons.forEach(({ nome, link, emoji }) => {
                    const button = new ButtonBuilder()
                        .setStyle(ButtonStyle.Link)
                        .setLabel(nome)
                        .setURL(link);

                    if (emoji) button.setEmoji(emoji);
                    rowSend.addComponents(button);
                });

                try {
                    await channel.send({
                        content: mensagem,
                        components: rowSend.components.length > 0 ? [rowSend] : [],
                        files: imagem ? [imagem] : []
                    });
                } catch {
                    await i.reply({ content: `${emj.get('13')} | Houve um erro ao processar o anúncio`, ephemeral: true });
                }
                return;
            }

            // Configura a mensagem
            if (i.customId === 'configmsg') {
                const msgModal = new ModalBuilder()
                    .setCustomId('configmsg')
                    .setTitle('Mensagem')
                    .addComponents(
                        new ActionRowBuilder()
                            .addComponents(
                                new TextInputBuilder()
                                    .setCustomId('text')
                                    .setLabel("Qual seria a nova mensagem?")
                                    .setStyle(TextInputStyle.Paragraph)
                            )
                    );

                await i.showModal(msgModal);
                const submitted = await i.awaitModalSubmit({ filter: i => i.customId === 'configmsg', time: 600_000 }).catch(() => {
                    i.reply({ content: `${emj.get('13')} | Tempo de espera esgotado!`, ephemeral: true });
                });
                if (!submitted) return;

                mensagem = submitted.fields.getTextInputValue('text');
                await submitted.deferUpdate();
                return;
            }

            // Configura a imagem
            if (i.customId === 'configimg') {
                const imgModal = new ModalBuilder()
                    .setCustomId('configimg')
                    .setTitle('Imagem')
                    .addComponents(
                        new ActionRowBuilder()
                            .addComponents(
                                new TextInputBuilder()
                                    .setCustomId('text')
                                    .setLabel("Qual seria a nova imagem?")
                                    .setPlaceholder("Envie o link dela!")
                                    .setStyle(TextInputStyle.Short)
                            )
                    );

                await i.showModal(imgModal);
                const submitted = await i.awaitModalSubmit({ filter: i => i.customId === 'configimg', time: 600_000 }).catch(() => {
                    i.reply({ content: `${emj.get('13')} | Tempo de espera esgotado!`, ephemeral: true });
                });
                if (!submitted) return;

                const link = submitted.fields.getTextInputValue('text');
                if (isValidUrl(link)) {
                    imagem = link;
                    await submitted.deferUpdate();
                } else {
                    await i.reply({ content: `${emj.get('13')} | Envie um link válido!`, ephemeral: true });
                }
                return;
            }

            // Configura os botões
            if (i.customId === 'configbuttons') {
                const buttonModal = new ModalBuilder()
                    .setCustomId('addbutton')
                    .setTitle('Adicionar Botão')
                    .addComponents(
                        new ActionRowBuilder()
                            .addComponents(new TextInputBuilder().setCustomId('text').setLabel("Nome do botão").setStyle(TextInputStyle.Short)),
                        new ActionRowBuilder()
                            .addComponents(new TextInputBuilder().setCustomId('emoji').setLabel("Emoji do botão (opcional)").setStyle(TextInputStyle.Short).setRequired(false)),
                        new ActionRowBuilder()
                            .addComponents(new TextInputBuilder().setCustomId('link').setLabel("Link do botão").setStyle(TextInputStyle.Short))
                    );

                await i.showModal(buttonModal);
                const submitted = await i.awaitModalSubmit({ filter: i => i.customId === 'addbutton', time: 600_000 }).catch(() => {
                    i.reply({ content: `${emj.get('13')} | Tempo de espera esgotado!`, ephemeral: true });
                });
                if (!submitted) return;

                const buttonData = {
                    nome: submitted.fields.getTextInputValue('text'),
                    emoji: submitted.fields.getTextInputValue('emoji') || "",
                    link: submitted.fields.getTextInputValue('link')
                };

                if (buttons.length >= 5) {
                    await i.reply({ content: `${emj.get('13')} | Não é possível adicionar mais botões!`, ephemeral: true });
                    return;
                }

                buttons.push(buttonData);
                await submitted.deferUpdate();
                return;
            }
        });

        collector.on('end', async () => {
            await msg.edit({ components: [] });
        });
    }
};

function isValidUrl(url) {
    const regex = /^(https?:\/\/)?([a-zA-Z0-9-]+\.)+[a-zA-Z]{2,6}(\/[^\s]*)?$/;
    return regex.test(url);
}

const { ApplicationCommandType, PermissionFlagsBits } = require('discord.js');
const { CloseAllTickets } = require('../../Functions/CreateTicket');


module.exports = {
  name: "closealltickets",
  description: "Deleta todos os tickets abertos",
  type: ApplicationCommandType.ChatInput,
  default_member_permissions: PermissionFlagsBits.Administrator.toString(),

  run: async (client, interaction) => {
    await CloseAllTickets(interaction);
  },
};
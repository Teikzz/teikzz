const {
  Client,
  ApplicationCommandOptionType,
  ChannelType,
  PermissionFlagsBits,
  EmbedBuilder,
} = require('discord.js');
const { getPermissions } = require("../../Functions/PermissionsCache.js");

module.exports = {
  name: 'clear',
  description: 'Limpa todas as mensagens de um canal e bloqueia temporariamente.',
  options: [
    {
      name: 'channel',
      description: 'O canal para limpar as mensagens.',
      type: ApplicationCommandOptionType.Channel,
      required: true,
      channelTypes: [ChannelType.GuildText],
    },
  ],
  default_member_permissions: PermissionFlagsBits.Administrator,

  run: async (client, interaction) => {
    const perm = await getPermissions(client.user.id);
    if (perm === null || !perm.includes(interaction.user.id)) {
      return interaction.reply({ content: `Sem permissão.`, ephemeral: true });
    }

    try {
      const channel = interaction.options.getChannel('channel');

      if (!channel || !channel.isTextBased()) {
        return interaction.reply({ content: 'Você deve selecionar um canal de texto.', ephemeral: true });
      }

      // Primeira embed indicando que o processo começou
      const clearingEmbed = new EmbedBuilder()
        .setColor('#0000CD')
        .setTitle('Limpeza em andamento...')
        .setDescription('O canal está sendo limpo. Por favor, aguarde.');

      const statusMessage = await channel.send({ embeds: [clearingEmbed] });

      // Bloqueia o canal para todos os cargos
      const roles = channel.guild.roles.cache.filter(role => role.name !== '@everyone');
      roles.forEach(async (role) => {
        await channel.permissionOverwrites.edit(role, { SendMessages: false });
      });

      // Segunda embed indicando que o chat foi bloqueado
      const blockedEmbed = new EmbedBuilder()
        .setColor('#0000CD')
        .setTitle('Canal Bloqueado')
        .setDescription('O canal foi temporariamente bloqueado para limpeza.');

      await channel.send({ embeds: [blockedEmbed] });

      // Parte que limpa todas as mensagens acima da primeira embed
      let totalDeleted = 0;
      let lastMessageId = statusMessage.id;

      while (true) {
        // Busca as mensagens anteriores (máx. 100 por busca)
        const fetchedMessages = await channel.messages.fetch({ limit: 100, before: lastMessageId });

        // Se não houver mensagens, sai do loop
        if (fetchedMessages.size === 0) break;

        // Deleta as mensagens em bloco e atualiza o ID da última mensagem
        await channel.bulkDelete(fetchedMessages, true);
        totalDeleted += fetchedMessages.size;
        lastMessageId = fetchedMessages.last().id;
      }

      // Atualiza a primeira embed com o total de mensagens apagadas
      const clearedEmbed = new EmbedBuilder()
        .setColor('#0000CD')
        .setTitle('Limpeza Concluída')
        .setDescription(`Total de \`${totalDeleted}\` mensagens apagadas.`);

      await statusMessage.edit({ embeds: [clearedEmbed] });

      // Desbloqueia o canal para todos os cargos
      roles.forEach(async (role) => {
        await channel.permissionOverwrites.edit(role, { SendMessages: true });
      });

      // Confirmação final
      await channel.send({ content: 'O canal foi desbloqueado e a limpeza foi concluída!' });
    } catch (error) {
      console.error(error);
      await interaction.reply({ content: 'Ocorreu um erro ao processar o comando.', ephemeral: true });
    }
  },
};
